// v61: only the agreed hinge bore and removal of the four door reliefs.
include <laser_cut_v60_hinge_power_common.scad>

// User-requested tight holes, NOT a free-running M4 clearance hole.
// Keep every v60 centre, 17/40mm pitch and external hinge axis unchanged.
hinge_hole_d_v49 = 3.5;

// Remove the four right-side hinge-head rectangles in BOTH door variants.
module hinge_head_reliefs_door_2d_v60() {}

// Display the chosen inside nut arrangement instead of v60's assumed 8mm head.
// AF=6.5mm, estimated thickness=2.5mm; the flats face the door (constant Y).
// Regular hexagon from AF=6.5 has a larger corner envelope than the approximate
// measured 7mm diagonal, so this reference does not assume both estimates exact.
hinge_nut_af_v61 = 6.5;
hinge_nut_t_v61 = 2.5;
module hinge_nut_flat_profile_v61() {
    r=hinge_nut_af_v61/sqrt(3);
    difference() {
        polygon([for(a=[30:60:330]) [r*cos(a),r*sin(a)]]);
        circle(d=4,$fn=48);
    }
}
module hinge_side_heads_v60() {
    for(z=hinge_hole_heights_v49(hinge_side_pitch_v49))
        multmatrix([[0,0,1,outer_width-panel_t-hinge_nut_t_v61],
                    [1,0,0,hinge_side_y_v49],
                    [0,1,0,z],[0,0,0,1]])
            linear_extrude(hinge_nut_t_v61) hinge_nut_flat_profile_v61();
}
