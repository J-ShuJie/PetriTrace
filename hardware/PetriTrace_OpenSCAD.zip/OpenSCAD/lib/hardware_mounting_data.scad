// 树莓派 5 与 Crowtail Shield for Raspberry Pi Pico v1.0 安装孔数据。
// 本文件只有尺寸变量和孔中心坐标，不生成任何实体。
// 坐标约定：俯视电路板，板外形左下角为 [0, 0]，单位 mm。

// 公共 M2.5 紧固参数。
m25_nominal_diameter = 2.5;
m25_printed_clearance_diameter = 3.0;
m25_printed_relaxed_clearance_diameter = 3.2;

// Raspberry Pi 5：四孔并不相对 85 x 56 mm 板外形居中。
rpi5_board_size = [85, 56];
rpi5_mounting_pitch = [58, 49];
rpi5_first_hole_center = [3.5, 3.5];
rpi5_mounting_hole_centers = [
    [3.5,  3.5],
    [61.5, 3.5],
    [3.5,  52.5],
    [61.5, 52.5]
];

// Crowtail Shield for Raspberry Pi Pico v1.0：
// 用户实测板外缘至圆孔外缘约 1.10..1.15 mm；孔用于 M2.5。
// 以 Ø2.8 mm PCB 通孔作为中心反算基准：1.1 + 2.8/2 = 2.5 mm。
// 因此采用四边中心偏移 2.5 mm、中心距 60 x 51 mm。
// 这是实物测量反算基准，不冒充厂商机械图；装配孔应保留打印余量。
crowtail_board_size = [65, 56];
crowtail_measured_edge_to_hole_edge = 1.1;
crowtail_reference_pcb_hole_diameter = 2.8;
crowtail_hole_center_edge_offset = 2.5;
crowtail_mounting_pitch = [60, 51];
crowtail_mounting_hole_centers = [
    [2.5,  2.5],
    [62.5, 2.5],
    [2.5,  53.5],
    [62.5, 53.5]
];

// Crowtail 孔位建议按 ±0.2 mm 的位置不确定度处理；
// 最终打印件默认使用 Ø3.0 mm，需更多装配余量时使用 Ø3.2 mm。
crowtail_center_position_uncertainty = 0.2;
