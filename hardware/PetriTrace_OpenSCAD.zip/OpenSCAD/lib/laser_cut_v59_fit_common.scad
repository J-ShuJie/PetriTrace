// v59 overrides only. The previous source model stays untouched.
include <laser_cut_v58_fit_common.scad>

// Move the complete external handle 5mm towards the middle of the door.
// Its two mounting holes and four receiving slots derive from this same origin.
handle_blade_x0_v42 = 8;
handle_clear_depth_v42 = 14; // 14mm body + two 3mm tabs = 20mm overall width
handle_outer_depth_v42 = 17;

// Pure T: the narrow screw channel ends inside the transverse nut pocket.
// A 2.2mm axial pocket contains a nominal 2mm nut and leaves 0.1mm at the
// 12mm screw tip when the screw is seated directly against the outer surface.
fit_nut_pocket_axial_v59 = 2.2;
screen_tnut_depth_v41 = 8;
module screen_lr_tnut_cut_2d(axis_s,edge="left") {
    cx=edge=="left" ? panel_t+screen_tnut_depth_v41
        : outer_width-panel_t-screen_tnut_depth_v41;
    translate([cx-fit_nut_pocket_axial_v59/2,axis_s-tnut_nut_af/2])
        square([fit_nut_pocket_axial_v59,tnut_nut_af]);
    if(edge=="left")
        translate([panel_t-0.01,axis_s-tnut_screw_d/2])
            square([cx-panel_t+0.01,tnut_screw_d]);
    else
        translate([cx,axis_s-tnut_screw_d/2])
            square([outer_width-panel_t-cx+0.01,tnut_screw_d]);
}
module screen_fifth_nut_slots_2d_v52() {
    for(s=screen_side_tnut_s_v41)
        for(x=[panel_t+screen_tnut_depth_v41,
               outer_width-panel_t-screen_tnut_depth_v41])
            translate([x-fit_nut_pocket_axial_v59/2,s-tnut_nut_af/2])
                square([fit_nut_pocket_axial_v59,tnut_nut_af]);
}
module handle_blade_inner_tnut_cut_2d_v42(global_z) {
    z=handle_local_z_v42(global_z);c=8;
    translate([c-fit_nut_pocket_axial_v59/2,z-tnut_nut_af/2])
        square([fit_nut_pocket_axial_v59,tnut_nut_af]);
    translate([-0.01,z-tnut_screw_d/2]) square([c+0.01,tnut_screw_d]);
}
module handle_blade_outer_tnut_cut_2d_v42(global_z) {
    z=handle_local_z_v42(global_z);c=handle_clear_depth_v42-8;
    translate([c-fit_nut_pocket_axial_v59/2,z-tnut_nut_af/2])
        square([fit_nut_pocket_axial_v59,tnut_nut_af]);
    translate([c,z-tnut_screw_d/2])
        square([handle_clear_depth_v42-c+0.01,tnut_screw_d]);
}
module handle_blade_2d_v42() {
    difference() {
        union() {
            square([handle_clear_depth_v42,handle_h_v42]);
            // Exactly 3mm insertion, with union overlap on the INSIDE only.
            // The tongue tips do not project past the 3mm door into its magnet plate.
            for(z=handle_inner_tab_global_z_v42)
                translate([-panel_t,handle_local_z_v42(z)])
                    square([panel_t+join_overlap,finger_w]);
            for(z=handle_outer_tab_global_z_v42)
                translate([handle_clear_depth_v42-join_overlap,handle_local_z_v42(z)])
                    square([panel_t+join_overlap,finger_w]);
        }
        for(z=handle_door_lock_global_z_v42) handle_blade_inner_tnut_cut_2d_v42(z);
        for(z=handle_return_lock_global_z_v42) handle_blade_outer_tnut_cut_2d_v42(z);
    }
}

// Restore the fixed side wall: no handle-related notches.
module handle_head_reliefs_2d_v58() {}

// Keep the box magnet plates, their tongues, and fixing-hole axes in place.
// Only their magnet window moves +2mm. Undo the unrequested v58 tail extension
// and restore the box-front countersinks from v57.
module body_magnet_side_tnut_cut_2d_v42(axis_z) {
    magnet_nut_relief_v53(axis_z);
    translate([magnet_plate_x0_v42-0.01,axis_z-tnut_screw_d/2])
        square([7.01,tnut_screw_d]);
}
module magnet_body_front_3d_v53() {
    difference() {
        xz_panel_3d(body_magnet_carrier_y_v42) body_magnet_carrier_2d_v42();
        magnet_countersinks_v53(body_magnet_face_y_v42,-1);
    }
}

// Trim the moving plate's wall-facing edge by an ADDITIONAL 2mm:
// X=3.2 becomes X=5.2. Keep its other edges and screw axes unchanged.
door_magnet_side_gap_v58 = 2.2;
magnet_center_v42 = [12.5,inner_height/2]; // both windows move from X=10.5 to12.5

// Avoid the legacy preview's hard-coded X=8 reference cubes.
module body_magnet_cassette_3d_v42() {
    color([0.23,0.63,0.69]) magnet_body_front_3d_v53();
    color([0.87,0.61,0.28]) xz_panel_3d(body_magnet_back_y_v42)
        body_magnet_backplate_2d_v42();
    %color([0.2,0.2,0.2])
        translate([magnet_center_v42[0]-2.5,body_magnet_face_y_v42-2,
                   magnet_center_v42[1]-5]) cube([5,2,10]);
}
module door_magnet_cassette_3d_v42() {
    color([0.63,0.66,0.73]) magnet_door_front_3d_v53();
    %color([0.2,0.2,0.2])
        translate([magnet_center_v42[0]-2.5,door_magnet_carrier_y_v42,
                   magnet_center_v42[1]-5]) cube([5,2,10]);
}
