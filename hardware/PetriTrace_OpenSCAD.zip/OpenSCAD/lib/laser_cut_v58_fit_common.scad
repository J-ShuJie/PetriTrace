// v58: obsolete screen hole/pad removal, real 12mm screw paths,
// and separate door-magnet clamp holes / opposing fastener clearances.
include <laser_cut_v57_front_tab_only_common.scad>

// Remove only obsolete A=(7.5,50); keep four dedicated stack clamps unchanged.
screen_stack_holes = [
    [20,5],[136,5],[150.5,35],[150.5,65],
    [5.5,15],[5.5,35],[150.5,15],[150.5,55]
];

// 12mm ordinary screws seated directly against the outer wall.
// Keep the original nut centers, add a 0.5mm space beyond the screw tip.
screen_screw_tip_limit_v58 = 12.5;
module screen_lr_tnut_cut_2d(axis_s,edge="left") {
    cx=edge=="left" ? panel_t+screen_tnut_depth_v41
        : outer_width-panel_t-screen_tnut_depth_v41;
    translate([cx-tnut_nut_thickness/2,axis_s-tnut_nut_af/2])
        square([tnut_nut_thickness,tnut_nut_af]);
    if(edge=="left")
        translate([panel_t-0.01,axis_s-tnut_screw_d/2])
            square([screen_screw_tip_limit_v58-panel_t+0.01,tnut_screw_d]);
    else
        translate([outer_width-screen_screw_tip_limit_v58,axis_s-tnut_screw_d/2])
            square([screen_screw_tip_limit_v58-panel_t+0.01,tnut_screw_d]);
}
// Same 12mm end clearance for the body magnet's two side T-locks.
module body_magnet_side_tnut_cut_2d_v42(axis_z) {
    magnet_nut_relief_v53(axis_z);
    translate([magnet_plate_x0_v42-0.01,axis_z-tnut_screw_d/2])
        square([12.5-magnet_plate_x0_v42+0.01,tnut_screw_d]);
}

// Widen the handle blade outward by 2mm. The matching return plate follows it.
handle_clear_depth_v42 = 12;
handle_outer_depth_v42 = 15;
module handle_blade_inner_tnut_cut_2d_v42(global_z) {
    z=handle_local_z_v42(global_z);c=8;
    translate([c-tnut_nut_thickness/2,z-tnut_nut_af/2])
        square([tnut_nut_thickness,tnut_nut_af]);
    translate([-0.01,z-tnut_screw_d/2]) square([9.51,tnut_screw_d]);
}
module handle_blade_outer_tnut_cut_2d_v42(global_z) {
    z=handle_local_z_v42(global_z);c=handle_clear_depth_v42-8;
    translate([c-tnut_nut_thickness/2,z-tnut_nut_af/2])
        square([tnut_nut_thickness,tnut_nut_af]);
    translate([handle_clear_depth_v42-9.5,z-tnut_screw_d/2])
        square([9.51,tnut_screw_d]);
}

// Door handle heads sit inside the door. These two small rear-edge wall notches
// accept an envelope up to 6mm diameter and 3mm total protrusion (+0.3 clearance).
// They are distinct from the magnet's opposing-head holes below.
fastener_envelope_d_v58 = 6;
fastener_envelope_h_v58 = 3;
head_clearance_v58 = 0.3;
module handle_head_reliefs_2d_v58() {
    for(z=handle_door_lock_global_z_v42)
        translate([door_inner_y_v42-fastener_envelope_h_v58-head_clearance_v58,
                   z-fastener_envelope_d_v58/2-head_clearance_v58])
            square([fastener_envelope_h_v58+head_clearance_v58+0.01,
                    fastener_envelope_d_v58+2*head_clearance_v58]);
}

// The body magnet remains centered at (10.5,97.5), with its old two clamp axes.
// The door magnet carrier is enlarged so its own clamp heads clear the body.
door_magnet_width_v58 = 21;  // nominal X=3..24 before the opening-clearance trim
door_magnet_side_gap_v58 = 0.2; // trim only the moving edge, X starts at 3.2
door_magnet_height_v58 = 54; // Z=70.5..124.5
door_magnet_bolt_z_v58 = [76,119];
opposing_head_hole_size_v58 = 6.6; // accepts D<=6, or AF5 hex nut in any in-plane angle
module door_magnet_bolt_holes_2d_v58() {
    for(z=door_magnet_bolt_z_v58)
        translate([magnet_plate_bolt_x_v42,z]) circle_2d(tnut_screw_d);
}
module door_magnet_carrier_2d_v42() {
    difference() {
        translate([magnet_plate_x0_v42+door_magnet_side_gap_v58,
                   magnet_center_v42[1]-door_magnet_height_v58/2])
            square([door_magnet_width_v58-door_magnet_side_gap_v58,door_magnet_height_v58]);
        magnet_window_2d_v42();
        door_magnet_bolt_holes_2d_v58();
        // Retain the two small clearances for the BODY SIDE nuts.
        magnet_door_nut_relief_2d_v54();
        // Add separate through-clearances for the opposing BODY AXIAL heads/nuts.
        for(z=magnet_plate_bolt_z_v42)
            translate([magnet_plate_bolt_x_v42-opposing_head_hole_size_v58/2,
                       z-opposing_head_hole_size_v58/2])
                square([opposing_head_hole_size_v58,opposing_head_hole_size_v58]);
    }
}
module door_panel_2d_v42() {
    difference() {
        square([outer_width,inner_height]);
        // Hinge layout/diameter deliberately unchanged pending measurements.
        for(z=hinge_hole_heights_v49(hinge_door_pitch_v49))
            translate([hinge_door_x_v49,z]) circle_2d(hinge_hole_d_v49);
        for(z=handle_inner_tab_global_z_v42)
            translate([handle_blade_x0_v42+(panel_t-slot_w)/2,z])
                square([slot_w,finger_w]);
        for(z=handle_door_lock_global_z_v42)
            translate([handle_blade_x0_v42+panel_t/2,z]) circle_2d(tnut_screw_d);
        door_magnet_bolt_holes_2d_v58();
    }
}
// Ordinary heads now have opposing clearance; no mandatory magnet countersinks.
module magnet_body_front_3d_v53() {
    xz_panel_3d(body_magnet_carrier_y_v42) body_magnet_carrier_2d_v42();
}
module magnet_door_front_3d_v53() {
    xz_panel_3d(door_magnet_carrier_y_v42) door_magnet_carrier_2d_v42();
}

module laser_cut_version_v58(mode="assembly") {
    if(mode=="rear_detail") {
        color([0.7,0.73,0.8,0.45]) intersection() {
            side_panel_3d(0,false,joint_system);
            translate([-1,82,45]) cube([5,15,105]);
        }
        body_magnet_cassette_3d_v42();
        rear_door_assembly_3d_v42();
    }
    else if(mode=="handle_parts") {
        linear_extrude(panel_t) handle_blade_2d_v42();
        translate([25,0,0]) linear_extrude(panel_t) handle_return_2d_v42();
    }
    else laser_cut_version_v53(mode);
}
