// Exact inherited profiles, renamed only for composable optional cuts.
module side_panel_base_v60(is_right = false, system = default_joint_system) {
    difference() {
        if (active_geometry_revision >= 2)
            union() {
                polygon(points = [
                    [-screen_base, 0],
                    [inner_depth, 0],
                    [inner_depth, inner_height],
                    [0, inner_height],
                    [0, screen_rise]
                ]);
                side_bottom_fingers_2d();
                side_top_fingers_2d();
            }
        else
            polygon(points = [
                [-screen_base, 0],
                [inner_depth, 0],
                [inner_depth, inner_height],
                [0, inner_height],
                [0, screen_rise]
            ]);

        if (active_geometry_revision < 2) {
            legacy_side_bottom_notches_2d();
            legacy_side_top_notches_2d();
        }

        side_front_notches_2d(is_right);
        for (s0 = screen_joint_starts)
            sloped_edge_notch_2d(s0);
        if (!is_right)
            side_shelf_slots_2d();

        if (system == "wood")
            wood_side_holes_2d();
        else if (system == "tnut") {
            for (y = tnut_axis_y) {
                tnut_edge_cut_2d(y, "bottom");
                tnut_edge_cut_2d(y, "top");
            }

            tnut_edge_cut_2d(right_triangle_bottom_tnut_y_v40,
                "bottom");

            for (z = front_side_tnut_z_v41)
                translate([panel_t / 2, z])
                    circle_2d(tnut_screw_d);

            for (s = screen_side_tnut_s_v41)
                translate(recess_global_point(
                    s,
                    screen_carrier_d + panel_t / 2
                )) circle_2d(tnut_screw_d);
        }

        if (!is_right)
            for (z = body_magnet_side_lock_z_v42)
                translate([body_magnet_side_hole_y_v42, z])
                    circle_2d(tnut_screw_d);

        if (!is_right) magnet_wall_slots_2d_v53();
        if (!is_right) handle_head_reliefs_2d_v58();

        if (is_right)
            right_side_hardware_holes_2d();
    }
}

module door_panel_base_v60() {
    difference() {
        square([outer_width,inner_height]);
        // Hinge layout/diameter deliberately unchanged pending measurements.
        for(z=hinge_hole_heights_v49(hinge_door_pitch_v49))
            translate([hinge_door_x_v49,z]) circle_2d(hinge_hole_d_v49);
        for(z=handle_inner_tab_global_z_v42)
            translate([handle_blade_x0_v42+(panel_t-slot_w)/2,z])
                square([slot_w,finger_w]);
        for(z=handle_door_lock_global_z_v42)
            translate([handle_blade_x0_v42+panel_t/2,z]) circle_2d(tnut_screw_d);
        door_magnet_bolt_holes_2d_v58();
    }
}
