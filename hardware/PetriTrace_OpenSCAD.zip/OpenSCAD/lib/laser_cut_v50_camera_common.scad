// Camera Module 3 mounting-hole addition; all other parts inherit v49A.
// Source: Raspberry Pi Camera Module 3 Product Brief, June 2024, page 4.
// https://datasheets.raspberrypi.com/camera/camera-module-3-product-brief.pdf
include <laser_cut_v49_hinge_common.scad>

camera_board_size_v50 = [25, 23.862];
camera_board_hole_d_v50 = 2.2;   // hardware PCB plain hole: use M2, not M2.5
camera_panel_hole_d_v50 = 2.4;   // chosen panel clearance; not a threaded hole
camera_lens_board_xy_v50 = [12.5, 14.4]; // measured from board left / cable-end edge
camera_board_holes_v50 = [[2, 2], [23, 2], [2, 14.5], [23, 14.5]];
camera_lens_center_v50 = [panel_t + work_bay_width / 2, inner_depth / 2];
// Cable end faces +X, towards the sensor side / central divider.
// Rotate the previous rear-facing placement clockwise 90 degrees about the lens.
function camera_to_shelf_v50(p) = [
    camera_lens_center_v50[0] - (p[1] - camera_lens_board_xy_v50[1]),
    camera_lens_center_v50[1] - (p[0] - camera_lens_board_xy_v50[0])
];
camera_holes_v50 = [for (p = camera_board_holes_v50) camera_to_shelf_v50(p)];

module camera_mount_holes_2d_v50() {
    for (p = camera_holes_v50)
        translate(p) circle_2d(camera_panel_hole_d_v50);
}

// Original lower shelf outline, tabs and square aperture, plus camera holes.
// v44 still adds the original five sensor holes in every assembly/layout path.
module lower_shelf_2d() {
    difference() {
        union() {
            translate([panel_t, panel_t])
                square([work_bay_width, inner_depth - panel_t]);
            shelf_side_tabs_2d();
        }
        translate([
            panel_t + (work_bay_width - small_hole_size) / 2,
            (inner_depth - small_hole_size) / 2
        ]) square([small_hole_size, small_hole_size]);
        camera_mount_holes_2d_v50();
    }
}

module camera_shelf_2d_v50() {
    difference() {
        lower_shelf_2d();
        sensor_mount_holes_2d_v44();
    }
}

module laser_cut_version_v50(mode = "assembly") {
    if (mode == "camera_shelf_2d") camera_shelf_2d_v50();
    else if (mode == "camera_shelf") linear_extrude(panel_t) camera_shelf_2d_v50();
    else laser_cut_version_v49(mode);
}
