// Independent geometry snapshot shared by both v38 fixing routes.
// Copied from v36/v37. It preserves the corrected right outer side and adds
// only the central-divider/front-panel finger joint plus the original sloped
// screen-rear clearance in the central divider.
// Units: mm. This file defines modules only and does not render by itself.

include <hardware_mounting_data.scad>

$fn = 48;

// Entry files must define panel_t, slot_w and finger_w before include.
// Keeping them out of this include lets v30 and v31 tune independently in
// OpenSCAD 2021, whose include assignments share one lexical scope.
join_overlap = 0.02; // numerical union overlap; does not change outer contour
default_joint_system = "wood";
default_preview_mode = "assembly";
default_geometry_revision = 2;
active_geometry_revision = is_undef(geometry_revision)
    ? default_geometry_revision
    : geometry_revision;

inner_width = 150;
inner_depth = 95;
inner_height = 195;
outer_width = inner_width + 2 * panel_t;       // 156
outer_rear_y = inner_depth + panel_t;          // 98
work_bay_width = 95;
divider_x = panel_t + work_bay_width;          // 98

screen_length = 95;
screen_base = 25;
screen_rise = sqrt(screen_length * screen_length
    - screen_base * screen_base);
screen_a = screen_base / screen_length;
screen_b = screen_rise / screen_length;
upper_front_z = screen_rise - panel_t * screen_a;

lower_shelf_z = 25;
upper_shelf_z = 167;
small_hole_size = 11;
large_opening_size = 81;

screen_opening_x = 8;
screen_opening_s = 10;
screen_opening_w = 140;
screen_opening_l = 75;
screen_front_outer_d = -panel_t;
screen_carrier_d = 2 * panel_t; // d=6; 9 mm behind the outer front face
screen_mount_required_depth = 8.5;
screen_mount_actual_depth = screen_carrier_d - screen_front_outer_d;
screen_mount_shim = screen_mount_actual_depth
    - screen_mount_required_depth;

screen_case_mounts = [
    [26.15, 22],
    [129.85, 22],
    [129.85, 73]
];

screen_pi_boss_x = 57.79;
screen_pi_boss_s = 72;
screen_pi_boss_d = (screen_base - screen_a * screen_pi_boss_s)
    / screen_b;
screen_pi_boss_front_z = screen_b * screen_pi_boss_s
    - screen_a * screen_pi_boss_d;

main_joint_starts = [10, 30, 50, 70];
bottom_front_joint_starts = [-20];
screen_joint_starts = [10, 30, 50, 70];
shelf_tab_starts = [10, 30, 50, 70];
shelf_front_tab_starts = [15, 45, 75];
divider_tab_starts = [5, 22, 68, 82];
divider_tab_w = 8;
front_lower_tab_starts = [32, 47, 84];
front_lower_tab_w = 8;
front_upper_tab_starts = [100, 120, 140, 160, 180];
front_top_tab_starts = [15, 45, 75, 105, 135];
screen_bottom_tab_starts = [20, 50, 80, 110, 140];

wood_screw_clearance = 3.2;
wood_cleat_size = 10;
wood_cleat_y0 = 20;
wood_cleat_length = 65;
// Bottom/top plate screws sit in the solid intervals between side fingers.
// Side screws are offset by 10 mm along the cleat, preventing the two screw
// axes from meeting inside a 10 x 10 mm cleat.
wood_side_screw_y = active_geometry_revision >= 2
    ? [35, 75]
    : [32, 68];
wood_plate_screw_y = active_geometry_revision >= 2
    ? [25, 65]
    : [44, 78];

tnut_screw_d = 3.4;       // M3 laser-cut clearance candidate
tnut_nut_af = 5.8;        // 5.5 AF nut + 0.3 fitting allowance
tnut_nut_thickness = 2.6;
// T-nut screws also use solid intervals between the side fingers.
tnut_axis_y = active_geometry_revision >= 2
    ? [25, 65]
    : [15, 75];
tnut_axis_from_edge = 8;

laser_m25_clearance = 3.0;
hinge_clearance = 4.5;

function recess_global_point(s, d) = [
    screen_a * s + screen_b * d - screen_base,
    screen_b * s - screen_a * d
];

recess_d_at_front_high =
    (screen_base - screen_a * (screen_opening_s + screen_opening_l))
    / screen_b;
recess_front_z_high = screen_b
    * (screen_opening_s + screen_opening_l)
    - screen_a * recess_d_at_front_high;
recess_front_z_low = screen_b
    * ((screen_base - screen_b * 8) / screen_a)
    - screen_a * 8;

module circle_2d(d) {
    circle(d = d, $fn = 48);
}

module slot_rect_2d(center_x, center_y, size_x, size_y) {
    translate([center_x - size_x / 2, center_y - size_y / 2])
        square([size_x, size_y], center = false);
}

module side_bottom_fingers_2d() {
    for (y0 = concat(bottom_front_joint_starts, main_joint_starts))
        translate([y0, -panel_t])
            square([finger_w, panel_t + join_overlap], center = false);
}

module legacy_side_bottom_notches_2d() {
    for (y0 = concat(bottom_front_joint_starts, main_joint_starts))
        translate([y0, -0.01])
            square([finger_w, panel_t + 0.02], center = false);
}

module side_top_fingers_2d() {
    for (y0 = main_joint_starts)
        translate([y0, inner_height - join_overlap])
            square([finger_w, panel_t + join_overlap], center = false);
}

module legacy_side_top_notches_2d() {
    for (y0 = main_joint_starts)
        translate([y0, inner_height - panel_t])
            square([finger_w, panel_t + 0.01], center = false);
}

module side_front_notches_2d(is_right = false) {
    if (!is_right)
        for (z0 = concat(front_lower_tab_starts, front_upper_tab_starts))
            translate([-0.01, z0])
                square([panel_t + 0.02,
                    z0 < upper_front_z ? front_lower_tab_w : finger_w]);
    else
        for (z0 = front_upper_tab_starts)
            translate([-0.01, z0])
                square([panel_t + 0.02, finger_w]);
}

module sloped_edge_notch_2d(s0, width = finger_w) {
    // Local u follows the sloped edge; n points into the side panel.
    // Revisions 1/2 accidentally used a 3 x 3 matrix. OpenSCAD interprets
    // multmatrix as a 3D affine matrix, so -screen_base was not an XY
    // translation and every notch moved 25 mm into the panel. Revision 3
    // uses a proper 4 x 4 affine matrix; the notches now open onto the edge.
    if (active_geometry_revision >= 3)
        multmatrix([
            [screen_a, screen_b, 0, -screen_base],
            [screen_b, -screen_a, 0, 0],
            [0, 0, 1, 0],
            [0, 0, 0, 1]
        ]) translate([s0, -0.01])
            square([width, panel_t + 0.02], center = false);
    else
        multmatrix([
            [screen_a, screen_b, -screen_base],
            [screen_b, -screen_a, 0],
            [0, 0, 1]
        ]) translate([s0, -0.01])
            square([width, panel_t + 0.02], center = false);
}

module side_shelf_slots_2d() {
    for (z0 = [lower_shelf_z, upper_shelf_z])
        for (y0 = shelf_tab_starts)
            translate([y0, z0])
                square([finger_w, slot_w], center = false);
}

module tnut_edge_cut_2d(axis_y, edge = "top") {
    center_z = edge == "top"
        ? inner_height - tnut_axis_from_edge
        : tnut_axis_from_edge;

    translate([
        axis_y - tnut_nut_af / 2,
        center_z - tnut_nut_thickness / 2
    ]) square([tnut_nut_af, tnut_nut_thickness], center = false);

    if (edge == "top")
        translate([axis_y - tnut_screw_d / 2, center_z])
            square([tnut_screw_d,
                inner_height - center_z + 0.01], center = false);
    else
        translate([axis_y - tnut_screw_d / 2, -0.01])
            square([tnut_screw_d, center_z + 0.01], center = false);
}

module wood_side_holes_2d() {
    for (y = wood_side_screw_y)
        for (z = [wood_cleat_size / 2,
            inner_height - wood_cleat_size / 2])
            translate([y, z]) circle_2d(wood_screw_clearance);
}

module right_side_hardware_holes_2d() {
    // Crowtail board remains at the v24/v28 measured coordinates.
    crowtail_y0 = (90 - crowtail_board_size[0]) / 2;
    crowtail_z0 = inner_height - 2.5 - crowtail_board_size[1];
    for (point = crowtail_mounting_hole_centers)
        translate([
            crowtail_y0 + point[0],
            crowtail_z0 + point[1]
        ]) circle_2d(laser_m25_clearance);

    // Existing external hinge hole centres from v27.
    for (z = [36, 54, 141, 159])
        translate([92.55, z]) circle_2d(hinge_clearance);
}

module side_panel_2d(is_right = false, system = default_joint_system) {
    difference() {
        if (active_geometry_revision >= 2)
            union() {
                polygon(points = [
                    [-screen_base, 0],
                    [inner_depth, 0],
                    [inner_depth, inner_height],
                    [0, inner_height],
                    [0, screen_rise]
                ]);
                side_bottom_fingers_2d();
                side_top_fingers_2d();
            }
        else
            polygon(points = [
                [-screen_base, 0],
                [inner_depth, 0],
                [inner_depth, inner_height],
                [0, inner_height],
                [0, screen_rise]
            ]);

        if (active_geometry_revision < 2) {
            legacy_side_bottom_notches_2d();
            legacy_side_top_notches_2d();
        }

        side_front_notches_2d(is_right);
        for (s0 = screen_joint_starts)
            sloped_edge_notch_2d(s0);
        // The shelves span only from the left outer side to the central
        // divider. Their left tabs mate with the left-side slots; the opposite
        // tabs mate with divider_shelf_slots_2d(). The right outer side has no
        // mating shelf and therefore must remain solid here.
        if (!is_right)
            side_shelf_slots_2d();

        if (system == "wood")
            wood_side_holes_2d();
        else if (system == "tnut")
            for (y = tnut_axis_y) {
                tnut_edge_cut_2d(y, "bottom");
                tnut_edge_cut_2d(y, "top");
            }

        if (is_right)
            right_side_hardware_holes_2d();
    }
}

module side_finger_receiver_notches_2d(include_front = false) {
    starts = include_front
        ? concat(bottom_front_joint_starts, main_joint_starts)
        : main_joint_starts;
    for (y0 = starts) {
        translate([-0.01, y0])
            square([panel_t + 0.02, finger_w]);
        translate([outer_width - panel_t - 0.01, y0])
            square([panel_t + 0.02, finger_w]);
    }
}

module legacy_side_tabs_for_horizontal_panel_2d(include_front = false) {
    starts = include_front
        ? concat(bottom_front_joint_starts, main_joint_starts)
        : main_joint_starts;
    for (y0 = starts) {
        translate([0, y0])
            square([panel_t + join_overlap, finger_w]);
        translate([outer_width - panel_t - join_overlap, y0])
            square([panel_t + join_overlap, finger_w]);
    }
}

module divider_receiver_slots_2d() {
    for (y0 = divider_tab_starts)
        translate([divider_x + (panel_t - slot_w) / 2, y0])
            square([slot_w, divider_tab_w], center = false);
}

module screen_bottom_slots_2d() {
    // The sloped front enters the bottom at about 75 degrees.
    projected_slot = slot_w / screen_b;
    for (x0 = screen_bottom_tab_starts)
        translate([x0, -screen_base - projected_slot / 2])
            square([finger_w, projected_slot], center = false);
}

module main_fastener_holes_horizontal_2d(system = default_joint_system) {
    if (system == "wood")
        for (x = [panel_t + wood_cleat_size / 2,
            outer_width - panel_t - wood_cleat_size / 2])
            for (y = wood_plate_screw_y)
                translate([x, y]) circle_2d(wood_screw_clearance);
    else if (system == "tnut")
        for (x = [panel_t / 2, outer_width - panel_t / 2])
            for (y = tnut_axis_y)
                translate([x, y]) circle_2d(tnut_screw_d);
}

module bottom_panel_2d(system = default_joint_system) {
    difference() {
        if (active_geometry_revision >= 2)
            translate([0, -screen_base])
                square([outer_width, outer_rear_y + screen_base]);
        else
            union() {
                translate([panel_t, -screen_base])
                    square([inner_width,
                        outer_rear_y + screen_base]);
                legacy_side_tabs_for_horizontal_panel_2d(true);
            }

        if (active_geometry_revision >= 2)
            side_finger_receiver_notches_2d(true);
        divider_receiver_slots_2d();
        screen_bottom_slots_2d();
        main_fastener_holes_horizontal_2d(system);
    }
}

module top_panel_2d(system = default_joint_system) {
    difference() {
        if (active_geometry_revision >= 2)
            square([outer_width, outer_rear_y]);
        else
            union() {
                translate([panel_t, 0])
                    square([inner_width, outer_rear_y]);
                legacy_side_tabs_for_horizontal_panel_2d(false);
            }

        if (active_geometry_revision >= 2)
            side_finger_receiver_notches_2d(false);
        divider_receiver_slots_2d();
        for (x0 = front_top_tab_starts)
            translate([x0, 0])
                square([finger_w, slot_w], center = false);
        main_fastener_holes_horizontal_2d(system);
    }
}

module divider_tabs_2d() {
    for (y0 = divider_tab_starts) {
        translate([y0, -panel_t])
            square([divider_tab_w, panel_t + join_overlap]);
        translate([y0, inner_height - join_overlap])
            square([divider_tab_w, panel_t + join_overlap]);
    }
}

module divider_shelf_slots_2d() {
    for (z0 = [lower_shelf_z, upper_shelf_z])
        for (y0 = shelf_tab_starts)
            translate([y0, z0])
                square([finger_w, slot_w], center = false);
}

module divider_front_slots_2d() {
    for (z0 = front_lower_tab_starts)
        translate([0, z0])
            square([slot_w, front_lower_tab_w], center = false);
}

module divider_upper_front_relief_2d() {
    // Above the sloped-front transition, the front panel spans the full box
    // width. Recess the divider's front edge by one panel thickness everywhere
    // except the five 10 mm tongues. Those tongues enter matching through-slots
    // in the front panel instead of occupying the same solid volume.
    difference() {
        translate([-0.01, upper_front_z])
            square([
                panel_t + 0.02,
                inner_height - upper_front_z + 0.01
            ]);
        for (z0 = front_upper_tab_starts)
            translate([-0.02, z0])
                square([panel_t + 0.04, finger_w]);
    }
}

module legacy_divider_recess_clearance_2d() {
    polygon(points = [
        recess_global_point(screen_opening_s, 0),
        recess_global_point(screen_opening_s + screen_opening_l, 0),
        recess_global_point(screen_opening_s + screen_opening_l, 8),
        recess_global_point(screen_opening_s, 8)
    ]);
}

module divider_pi_holes_2d() {
    pi_y0 = (90 - rpi5_board_size[1]) / 2;
    pi_z0 = 5;
    for (point = rpi5_mounting_hole_centers)
        translate([pi_y0 + point[1], pi_z0 + point[0]])
            circle_2d(laser_m25_clearance);
}

module divider_cable_openings_2d() {
    translate([35, 0]) square([20, 10]);
    translate([35, 95]) square([20, 10]);
}

module central_divider_2d() {
    difference() {
        union() {
            square([inner_depth, inner_height]);
            divider_tabs_2d();
        }
        divider_shelf_slots_2d();
        divider_front_slots_2d();
        divider_upper_front_relief_2d();
        // This is a functional clearance for the screen-rear projection, not
        // a legacy decorative hole. Restore the exact original 8 mm envelope.
        legacy_divider_recess_clearance_2d();
        divider_pi_holes_2d();
        divider_cable_openings_2d();
    }
}

module front_panel_tabs_2d() {
    // Left outer side, full lower + upper span.
    for (z0 = concat(front_lower_tab_starts, front_upper_tab_starts))
        translate([0, z0])
            square([panel_t + join_overlap,
                z0 < upper_front_z ? front_lower_tab_w : finger_w]);

    // Right outer side exists only above the sloped front.
    for (z0 = front_upper_tab_starts)
        translate([outer_width - panel_t - join_overlap, z0])
            square([panel_t + join_overlap, finger_w]);

    // Lower extension locks into the central divider.
    for (z0 = front_lower_tab_starts)
        translate([divider_x - join_overlap, z0])
            square([panel_t + join_overlap, front_lower_tab_w]);

    // The top edge locks into the top plate.
    for (x0 = front_top_tab_starts)
        translate([x0, inner_height - join_overlap])
            square([finger_w, panel_t + join_overlap]);
}

module front_panel_divider_upper_slots_2d() {
    // Match the five retained tongues on the central divider. The slot is
    // centred on the divider's 3 mm material thickness and uses the established
    // 2.9 mm laser-fit candidate width.
    for (z0 = front_upper_tab_starts)
        translate([
            divider_x + (panel_t - slot_w) / 2,
            z0
        ]) square([slot_w, finger_w], center = false);
}

module front_panel_2d() {
    difference() {
        union() {
            translate([panel_t, upper_front_z])
                square([inner_width, inner_height - upper_front_z]);
            translate([panel_t, lower_shelf_z])
                square([work_bay_width, upper_front_z - lower_shelf_z]);
            front_panel_tabs_2d();
        }

        front_panel_divider_upper_slots_2d();

        if (active_geometry_revision < 2)
            translate([
                screen_opening_x,
                recess_front_z_low
            ]) square([
                screen_opening_w,
                recess_front_z_high - recess_front_z_low
            ]);

        // The one measured screen boss that reaches this front plate.
        translate([screen_pi_boss_x, screen_pi_boss_front_z])
            circle_2d(6.3);

        // Horizontal shelves enter this plate with three tabs each.
        for (z0 = [lower_shelf_z, upper_shelf_z])
            for (x0 = shelf_front_tab_starts)
                translate([x0, z0])
                    square([finger_w, slot_w]);
    }
}

module shelf_side_tabs_2d() {
    for (y0 = shelf_tab_starts) {
        translate([0, y0])
            square([panel_t + join_overlap, finger_w]);
        translate([divider_x - join_overlap, y0])
            square([panel_t + join_overlap, finger_w]);
    }
    for (x0 = shelf_front_tab_starts)
        translate([x0, 0])
            square([finger_w, panel_t + join_overlap]);
}

module lower_shelf_2d() {
    difference() {
        union() {
            translate([panel_t, panel_t])
                square([work_bay_width, inner_depth - panel_t]);
            shelf_side_tabs_2d();
        }
        translate([
            panel_t + (work_bay_width - small_hole_size) / 2,
            (inner_depth - small_hole_size) / 2
        ]) square([small_hole_size, small_hole_size]);
    }
}

module upper_shelf_2d() {
    difference() {
        union() {
            translate([panel_t, panel_t])
                square([work_bay_width, inner_depth - panel_t]);
            shelf_side_tabs_2d();
        }
        translate([
            panel_t + (work_bay_width - large_opening_size) / 2,
            (inner_depth - large_opening_size) / 2
        ]) square([large_opening_size, large_opening_size]);
    }
}

module screen_side_tabs_2d() {
    for (s0 = screen_joint_starts) {
        translate([0, s0])
            square([panel_t + join_overlap, finger_w]);
        translate([outer_width - panel_t - join_overlap, s0])
            square([panel_t + join_overlap, finger_w]);
    }
}

module screen_bottom_tabs_2d() {
    tab_length = panel_t / screen_b + 0.1;
    for (x0 = screen_bottom_tab_starts)
        translate([x0, -tab_length])
            square([finger_w, tab_length + join_overlap]);
}

screen_stack_holes = [
    [20, 5], [136, 5],
    [7.5, 50],
    [150.5, 35], [150.5, 65]
];

module screen_stack_holes_2d() {
    for (p = screen_stack_holes)
        translate(p) circle_2d(laser_m25_clearance);
}

module screen_outer_frame_2d() {
    difference() {
        square([outer_width, screen_length]);
        translate([screen_opening_x, screen_opening_s])
            square([screen_opening_w, screen_opening_l]);
        screen_stack_holes_2d();
    }
}

module screen_structural_frame_2d() {
    difference() {
        union() {
            // Open skeleton: bottom bar plus side rails. The rails stop before
            // reaching the vertical front plate; side fingers end at s=80.
            translate([panel_t, 0])
                square([inner_width, screen_opening_s]);
            translate([panel_t, 0]) square([5, 80]);
            translate([outer_width - panel_t - 5, 0]) square([5, 80]);
            translate([panel_t, 44]) square([9, 12]);
            screen_side_tabs_2d();
            screen_bottom_tabs_2d();
        }
        screen_stack_holes_2d();
    }
}

module screen_spacer_frame_2d() {
    difference() {
        union() {
            translate([panel_t, 0])
                square([inner_width, screen_opening_s]);
            translate([panel_t, 0]) square([5, 70]);
            translate([outer_width - panel_t - 5, 0]) square([5, 80]);
            translate([panel_t, 44]) square([9, 12]);
        }
        screen_stack_holes_2d();
    }
}

module screen_rear_carrier_2d() {
    difference() {
        union() {
            // One connected asymmetric carrier: bottom bar, short left rail,
            // full right rail and three arms. It deliberately avoids both the
            // front plate and the central divider.
            translate([panel_t, 0])
                square([inner_width, screen_opening_s]);
            translate([panel_t, 0]) square([5, 60]);
            translate([outer_width - panel_t - 5, 0]) square([5, 80]);
            translate([panel_t, 44]) square([9, 12]);
            translate([panel_t, 16]) square([29.15, 12]);
            translate([123.85, 16]) square([29.15, 12]);
            translate([123.85, 67]) square([29.15, 12]);
        }
        screen_stack_holes_2d();
        for (p = screen_case_mounts)
            translate(p) circle_2d(laser_m25_clearance);
    }
}

module side_panel_3d(x0, is_right = false, system = default_joint_system) {
    color(is_right ? [0.72, 0.76, 0.83] : [0.82, 0.84, 0.88])
        multmatrix([
            [0, 0, 1, x0],
            [1, 0, 0, 0],
            [0, 1, 0, 0],
            [0, 0, 0, 1]
        ]) linear_extrude(panel_t)
            side_panel_2d(is_right, system);
}

module yz_panel_3d(x0, panel_module = 0) {
    multmatrix([
        [0, 0, 1, x0],
        [1, 0, 0, 0],
        [0, 1, 0, 0],
        [0, 0, 0, 1]
    ]) linear_extrude(panel_t) children();
}

module xz_panel_3d(y0) {
    multmatrix([
        [1, 0, 0, 0],
        [0, 0, 1, y0],
        [0, 1, 0, 0],
        [0, 0, 0, 1]
    ]) linear_extrude(panel_t) children();
}

module on_sloped_front() {
    multmatrix([
        [1, 0, 0, 0],
        [0, screen_a, screen_b, -screen_base],
        [0, screen_b, -screen_a, 0],
        [0, 0, 0, 1]
    ]) children();
}

module wood_cleat_references_3d() {
    if (show_fastener_references)
        for (x0 = [panel_t, outer_width - panel_t - wood_cleat_size])
            for (z0 = [0, inner_height - wood_cleat_size])
                %color([0.56, 0.31, 0.12, 0.65])
                    translate([x0, wood_cleat_y0, z0])
                        cube([
                            wood_cleat_size,
                            wood_cleat_length,
                            wood_cleat_size
                        ]);
}

module tnut_references_3d() {
    if (show_fastener_references)
        for (x = [panel_t / 2, outer_width - panel_t / 2])
            for (y = tnut_axis_y)
                for (z = [tnut_axis_from_edge,
                    inner_height - tnut_axis_from_edge])
                    %color([0.90, 0.68, 0.10, 0.78])
                        translate([x, y, z - tnut_nut_thickness / 2])
                            cylinder(
                                h = tnut_nut_thickness,
                                d = 6.2,
                                $fn = 6
                            );
}

module screen_stack_3d() {
    color([0.18, 0.22, 0.30])
        on_sloped_front()
            translate([0, 0, screen_front_outer_d])
                linear_extrude(panel_t) screen_outer_frame_2d();

    color([0.34, 0.39, 0.46, 0.88])
        on_sloped_front()
            linear_extrude(panel_t) screen_structural_frame_2d();

    color([0.40, 0.45, 0.52, 0.78])
        on_sloped_front()
            translate([0, 0, panel_t])
                linear_extrude(panel_t) screen_spacer_frame_2d();

    color([0.64, 0.44, 0.18])
        on_sloped_front()
            translate([0, 0, screen_carrier_d])
                if (!is_undef(screen_upgrade_v51) && screen_upgrade_v51)
                    screen_rear_carrier_3d_v51();
                else linear_extrude(panel_t) screen_rear_carrier_2d();
}

module enclosure_assembly(system = default_joint_system) {
    side_panel_3d(0 - explode_distance, false, system);
    side_panel_3d(outer_width - panel_t + explode_distance,
        true, system);

    color([0.47, 0.55, 0.62])
        translate([0, 0, -panel_t - explode_distance])
            linear_extrude(panel_t) bottom_panel_2d(system);
    color([0.47, 0.55, 0.62])
        translate([0, 0, inner_height + explode_distance])
            linear_extrude(panel_t) top_panel_2d(system);

    color([0.43, 0.62, 0.70])
        yz_panel_3d(divider_x)
            central_divider_2d();

    color([0.79, 0.80, 0.84])
        xz_panel_3d(0)
            front_panel_2d();

    color([0.43, 0.70, 0.58])
        translate([0, 0, lower_shelf_z])
            linear_extrude(panel_t) lower_shelf_2d();
    color([0.51, 0.74, 0.64])
        translate([0, 0, upper_shelf_z])
            linear_extrude(panel_t) upper_shelf_2d();

    screen_stack_3d();

    if (system == "wood")
        wood_cleat_references_3d();
    else if (system == "tnut")
        tnut_references_3d();
}

module flat_layout(system = default_joint_system) {
    color([0.82, 0.84, 0.88])
        linear_extrude(panel_t) side_panel_2d(false, system);
    translate([130, 0, 0])
        color([0.72, 0.76, 0.83])
            linear_extrude(panel_t) side_panel_2d(true, system);

    translate([260, 25, 0])
        color([0.47, 0.55, 0.62])
            linear_extrude(panel_t) bottom_panel_2d(system);
    translate([260, 160, 0])
        color([0.47, 0.55, 0.62])
            linear_extrude(panel_t) top_panel_2d(system);

    translate([0, 225, 0])
        color([0.43, 0.62, 0.70])
            linear_extrude(panel_t) central_divider_2d();
    translate([115, 225, 0])
        color([0.79, 0.80, 0.84])
            linear_extrude(panel_t) front_panel_2d();

    translate([290, 280, 0])
        color([0.43, 0.70, 0.58])
            linear_extrude(panel_t) lower_shelf_2d();
    translate([400, 280, 0])
        color([0.51, 0.74, 0.64])
            linear_extrude(panel_t) upper_shelf_2d();

    translate([0, 445, 0])
        linear_extrude(panel_t) screen_outer_frame_2d();
    translate([170, 445, 0])
        linear_extrude(panel_t) screen_structural_frame_2d();
    translate([340, 445, 0])
        linear_extrude(panel_t) screen_spacer_frame_2d();
    translate([510, 445, 0])
        if (!is_undef(screen_upgrade_v51) && screen_upgrade_v51)
            screen_rear_carrier_3d_v51();
        else linear_extrude(panel_t) screen_rear_carrier_2d();
}

module screen_only_preview() {
    screen_stack_3d();
    %color([0.05, 0.42, 0.78, 0.25])
        on_sloped_front()
            translate([
                6.3,
                1.77,
                screen_front_outer_d - 0.7
            ])
                cube([143.4, 91.46, 0.7]);
}

module screen_front_collision_only() {
    color([0.95, 0.05, 0.03])
        intersection() {
            screen_stack_3d();
            xz_panel_3d(0) front_panel_2d();
        }
}

module screen_divider_collision_only() {
    color([0.95, 0.05, 0.03])
        intersection() {
            screen_stack_3d();
            yz_panel_3d(divider_x) central_divider_2d();
        }
}

coupon_slot_widths = [2.80, 2.85, 2.90, 2.95, 3.00];

module kerf_coupon_2d() {
    // The five open slots run left-to-right in coupon_slot_widths order.
    difference() {
        square([70, 25], center = false);
        for (i = [0 : len(coupon_slot_widths) - 1])
            translate([
                10 + i * 12 - coupon_slot_widths[i] / 2,
                13
            ]) square([coupon_slot_widths[i], 12.01]);
    }

    // Separate 3 mm nominal tongue/offcut reference.
    translate([75, 0])
        square([20, 25], center = false);
}

module laser_cut_version(
    system = default_joint_system,
    mode = default_preview_mode
) {
    if (mode == "assembly")
        enclosure_assembly(system);
    else if (mode == "layout")
        flat_layout(system);
    else if (mode == "screen")
        screen_only_preview();
    else if (mode == "divider")
        linear_extrude(panel_t) central_divider_2d();
    else if (mode == "front")
        linear_extrude(panel_t) front_panel_2d();
    else if (mode == "left_side")
        linear_extrude(panel_t) side_panel_2d(false, system);
    else if (mode == "right_side")
        linear_extrude(panel_t) side_panel_2d(true, system);
    else if (mode == "bottom")
        linear_extrude(panel_t) bottom_panel_2d(system);
    else if (mode == "coupon")
        linear_extrude(panel_t) kerf_coupon_2d();
    else if (mode == "screen_front_collision")
        screen_front_collision_only();
    else if (mode == "screen_divider_collision")
        screen_divider_collision_only();
    else
        assert(false, str("Unknown preview_mode: ", mode));
}
