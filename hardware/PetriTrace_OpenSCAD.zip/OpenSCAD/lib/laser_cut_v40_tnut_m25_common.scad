// 第40版共享修正：只服务于T形螺母槽路线。
// 基线为第39版，保留其小隔板大开口及此前全部指接/避让结构。
// 本版统一采用M2.5紧固件，并新增两类锁紧点：
// 1. 正面异形板上沿与顶板之间的左右两个T槽；
// 2. 右侧三角前伸部与底板之间的一个T槽。

include <laser_cut_v39_restored_opening_common.scad>

// M2.5激光切割候选尺寸。孔径留出约0.3 mm直径余量；
// 螺母槽按M2.5标准六角螺母5.0 mm对边、2.0 mm厚度建立。
tnut_screw_d = 2.8;
tnut_nut_af = 5.0;
tnut_nut_thickness = 2.0;
laser_m25_clearance = 2.8;
m25_nut_ac_v40 = 5.45;

front_top_tnut_x_v40 = [35, 125];
right_triangle_bottom_tnut_y_v40 = -5;

// 第39版正面异形板：保留大开口，并在顶边两个插齿间隙内加入T槽。
module front_panel_2d() {
    difference() {
        union() {
            translate([panel_t, upper_front_z])
                square([inner_width, inner_height - upper_front_z]);
            translate([panel_t, lower_shelf_z])
                square([work_bay_width, upper_front_z - lower_shelf_z]);
            front_panel_tabs_2d();
        }

        front_panel_divider_upper_slots_2d();

        translate([
            screen_opening_x,
            recess_front_z_low
        ]) square([
            screen_opening_w,
            recess_front_z_high - recess_front_z_low
        ]);

        translate([screen_pi_boss_x, screen_pi_boss_front_z])
            circle_2d(6.3);

        for (z0 = [lower_shelf_z, upper_shelf_z])
            for (x0 = shelf_front_tab_starts)
                translate([x0, z0])
                    square([finger_w, slot_w]);

        for (x = front_top_tnut_x_v40)
            tnut_edge_cut_2d(x, "top");
    }
}

// 右侧板在原有箱体四组T槽之外，仅在前凸三角区、现有前指接齿
// 与箱体竖直前缘之间的完整板段加入一个底部T槽。左侧板不增加。
module side_panel_2d(is_right = false, system = default_joint_system) {
    difference() {
        if (active_geometry_revision >= 2)
            union() {
                polygon(points = [
                    [-screen_base, 0],
                    [inner_depth, 0],
                    [inner_depth, inner_height],
                    [0, inner_height],
                    [0, screen_rise]
                ]);
                side_bottom_fingers_2d();
                side_top_fingers_2d();
            }
        else
            polygon(points = [
                [-screen_base, 0],
                [inner_depth, 0],
                [inner_depth, inner_height],
                [0, inner_height],
                [0, screen_rise]
            ]);

        if (active_geometry_revision < 2) {
            legacy_side_bottom_notches_2d();
            legacy_side_top_notches_2d();
        }

        side_front_notches_2d(is_right);
        for (s0 = screen_joint_starts)
            sloped_edge_notch_2d(s0);
        if (!is_right)
            side_shelf_slots_2d();

        if (system == "wood")
            wood_side_holes_2d();
        else if (system == "tnut") {
            for (y = tnut_axis_y) {
                tnut_edge_cut_2d(y, "bottom");
                tnut_edge_cut_2d(y, "top");
            }
            if (is_right)
                tnut_edge_cut_2d(right_triangle_bottom_tnut_y_v40,
                    "bottom");
        }

        if (is_right)
            right_side_hardware_holes_2d();
    }
}

module bottom_panel_2d(system = default_joint_system) {
    difference() {
        if (active_geometry_revision >= 2)
            translate([0, -screen_base])
                square([outer_width, outer_rear_y + screen_base]);
        else
            union() {
                translate([panel_t, -screen_base])
                    square([inner_width,
                        outer_rear_y + screen_base]);
                legacy_side_tabs_for_horizontal_panel_2d(true);
            }

        if (active_geometry_revision >= 2)
            side_finger_receiver_notches_2d(true);
        divider_receiver_slots_2d();
        screen_bottom_slots_2d();
        main_fastener_holes_horizontal_2d(system);

        if (system == "tnut")
            translate([
                outer_width - panel_t / 2,
                right_triangle_bottom_tnut_y_v40
            ]) circle_2d(tnut_screw_d);
    }
}

module top_panel_2d(system = default_joint_system) {
    difference() {
        if (active_geometry_revision >= 2)
            square([outer_width, outer_rear_y]);
        else
            union() {
                translate([panel_t, 0])
                    square([inner_width, outer_rear_y]);
                legacy_side_tabs_for_horizontal_panel_2d(false);
            }

        if (active_geometry_revision >= 2)
            side_finger_receiver_notches_2d(false);
        divider_receiver_slots_2d();
        for (x0 = front_top_tab_starts)
            translate([x0, 0])
                square([finger_w, slot_w], center = false);
        main_fastener_holes_horizontal_2d(system);

        if (system == "tnut")
            for (x = front_top_tnut_x_v40)
                translate([x, panel_t / 2])
                    circle_2d(tnut_screw_d);
    }
}

// 更新五金参考：旧四角T槽、新增顶部前板两点和右前三角区一点
// 全部显示为M2.5标准螺母包络；仅用于观察，不参与切割。
module tnut_references_3d() {
    if (show_fastener_references) {
        for (x = [panel_t / 2, outer_width - panel_t / 2])
            for (y = tnut_axis_y)
                for (z = [tnut_axis_from_edge,
                    inner_height - tnut_axis_from_edge])
                    %color([0.90, 0.68, 0.10, 0.78])
                        translate([x, y,
                            z - tnut_nut_thickness / 2])
                            cylinder(
                                h = tnut_nut_thickness,
                                d = m25_nut_ac_v40,
                                $fn = 6
                            );

        for (x = front_top_tnut_x_v40)
            %color([0.90, 0.68, 0.10, 0.78])
                translate([
                    x,
                    panel_t / 2,
                    inner_height - tnut_axis_from_edge
                        - tnut_nut_thickness / 2
                ]) cylinder(
                    h = tnut_nut_thickness,
                    d = m25_nut_ac_v40,
                    $fn = 6
                );

        %color([0.90, 0.68, 0.10, 0.78])
            translate([
                outer_width - panel_t / 2,
                right_triangle_bottom_tnut_y_v40,
                tnut_axis_from_edge - tnut_nut_thickness / 2
            ]) cylinder(
                h = tnut_nut_thickness,
                d = m25_nut_ac_v40,
                $fn = 6
            );
    }
}
