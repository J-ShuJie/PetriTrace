// Independent v53 copy of the v52 five-layer assembly.
magnet_face_gap_v53 = 0.3;
include <laser_cut_v52_five_layer_common.scad>

body_magnet_face_y_v42 = inner_depth-panel_t-magnet_face_gap_v53;
body_magnet_side_lock_z_v42 = [80,115];
body_magnet_height_v53 = 44;
body_magnet_z0_v53 = magnet_center_v42[1]-body_magnet_height_v53/2;
magnet_front_tabs_v53 = [[92.5,10]];
magnet_back_tabs_v53 = [[84,6],[105,6]];
magnet_tab_clearance_v53 = 0.05; // TOTAL nominal slot oversize, not per side
magnet_nut_x_v53 = 2.2;
magnet_nut_z_v53 = 5.2;
magnet_countersink_d_v53 = 5.0; // M2.5, assumed head envelope; measure actual head
magnet_countersink_depth_v53 = (magnet_countersink_d_v53-tnut_screw_d)/2;

module magnet_body_blank_v53(tabs) {
    union() {
        translate([magnet_plate_x0_v42,body_magnet_z0_v53])
            square([magnet_plate_w_v42,body_magnet_height_v53]);
        for(t=tabs) translate([0,t[0]]) square([panel_t+0.02,t[1]]);
    }
}
module magnet_nut_relief_v53(z) {
    translate([10-magnet_nut_x_v53/2,z-magnet_nut_z_v53/2])
        square([magnet_nut_x_v53,magnet_nut_z_v53]);
}
module body_magnet_side_tnut_cut_2d_v42(axis_z) {
    magnet_nut_relief_v53(axis_z);
    translate([magnet_plate_x0_v42-0.01,axis_z-tnut_screw_d/2])
        square([7.01,tnut_screw_d]);
}
module body_magnet_carrier_2d_v42() {
    difference() {
        magnet_body_blank_v53(magnet_front_tabs_v53);
        magnet_window_2d_v42();
        magnet_plate_bolt_holes_2d_v42();
        for(z=body_magnet_side_lock_z_v42) body_magnet_side_tnut_cut_2d_v42(z);
    }
}
module body_magnet_backplate_2d_v42() {
    difference() {
        magnet_body_blank_v53(magnet_back_tabs_v53);
        magnet_plate_bolt_holes_2d_v42();
        for(z=body_magnet_side_lock_z_v42) magnet_nut_relief_v53(z);
    }
}
module magnet_wall_slots_2d_v53() {
    for(pair=[[body_magnet_carrier_y_v42,magnet_front_tabs_v53],
              [body_magnet_back_y_v42,magnet_back_tabs_v53]])
        for(t=pair[1]) translate([pair[0]-magnet_tab_clearance_v53/2,
                                  t[0]-magnet_tab_clearance_v53/2])
            square([panel_t+magnet_tab_clearance_v53,t[1]+magnet_tab_clearance_v53]);
}
// Secondary 90-degree countersink, not made by the 2D laser pass.
// Screw heads face the magnetic gap; nuts face the box interior / door exterior.
module magnet_countersinks_v53(face_y,into_y) {
    for(z=magnet_plate_bolt_z_v42)
        translate([magnet_plate_bolt_x_v42,face_y,z])
            rotate([into_y>0 ? -90 : 90,0,0])
                cylinder(h=magnet_countersink_depth_v53,
                         d1=magnet_countersink_d_v53,d2=tnut_screw_d,$fn=48);
}
module magnet_body_front_3d_v53() {
    difference() {
        xz_panel_3d(body_magnet_carrier_y_v42) body_magnet_carrier_2d_v42();
        magnet_countersinks_v53(body_magnet_face_y_v42,-1);
    }
}
module magnet_door_front_3d_v53() {
    difference() {
        xz_panel_3d(door_magnet_carrier_y_v42) door_magnet_carrier_2d_v42();
        magnet_countersinks_v53(door_magnet_carrier_y_v42,1);
    }
}
module body_magnet_cassette_3d_v42() {
    color([0.23,0.63,0.69]) magnet_body_front_3d_v53();
    color([0.87,0.61,0.28]) xz_panel_3d(body_magnet_back_y_v42)
        body_magnet_backplate_2d_v42();
    // 2mm magnet flush with carrier: needs 1mm adhesive shim behind it.
    %color([0.2,0.2,0.2]) translate([8,body_magnet_face_y_v42-2,92.5]) cube([5,2,10]);
}
module door_magnet_cassette_3d_v42() {
    color([0.63,0.66,0.73]) magnet_door_front_3d_v53();
    %color([0.2,0.2,0.2]) translate([8,door_magnet_carrier_y_v42,92.5]) cube([5,2,10]);
}
module laser_cut_version_v53(mode="assembly") {
    if(mode=="magnet_detail") {
        color([0.7,0.73,0.8,0.5]) intersection() {
            side_panel_3d(0,false,joint_system);
            translate([-1,81,72]) cube([5,16,51]);
        }
        body_magnet_cassette_3d_v42();
        door_magnet_cassette_3d_v42();
    }
    else laser_cut_version_v52(mode);
}
