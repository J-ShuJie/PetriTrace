// v51 corrected: retain original round holes; side T slots retain nut rectangles
// only. Screw access is a horizontal drilled bore inside the 3mm plate.
include <laser_cut_v50_camera_common.scad>

screen_upgrade_v51 = true;
screen_bottom_gap_v51 = 0.25;
screen_front_gap_v51 = 1.0;
screen_side_bore_d_v51 = 2.8;
screen_bottom_slot_gap_v51 = 0.1;
screen_carrier_left_end_v51 = 58;
screen_spacer_left_end_v51 = 69;
// screen_stack_holes inherits the exact v50 positions, including bottom s=5.

function screen_min_s_v51(rear_d) =
    (screen_a * rear_d + screen_bottom_gap_v51) / screen_b;

module screen_body_above_floor_v51(rear_d) {
    intersection() {
        children();
        translate([-10, screen_min_s_v51(rear_d)])
            square([outer_width + 20, screen_length + 20]);
    }
}

// The bottom tabs stay connected to the raised structural-layer bottom bar.
// Their lowest corner ends 0.1mm above the underside of the base plate.
module screen_bottom_tabs_2d() {
    s_low = (-panel_t + 0.1 + screen_a * panel_t) / screen_b;
    s_high = screen_min_s_v51(panel_t) + join_overlap;
    for (x0 = screen_bottom_tab_starts)
        translate([x0, s_low]) square([finger_w, s_high - s_low]);
}

// Full projection of an inclined 3mm tab through the horizontal base, rather
// than the former symmetric slot that left solid material behind the tab.
module screen_bottom_slots_2d() {
    y_low = -screen_base - panel_t * screen_a / screen_b
        - screen_bottom_slot_gap_v51;
    y_high = -screen_base + panel_t / screen_b
        + screen_bottom_slot_gap_v51;
    for (x0 = screen_bottom_tab_starts)
        translate([x0 - screen_bottom_slot_gap_v51, y_low])
            square([finger_w + 2 * screen_bottom_slot_gap_v51, y_high - y_low]);
}

module screen_structural_frame_2d() {
    difference() {
        union() {
            screen_body_above_floor_v51(panel_t)
                union() {
                    translate([panel_t, 0]) square([inner_width, screen_opening_s]);
                    translate([panel_t, 0]) square([5, 80]);
                    translate([outer_width-panel_t-5, 0]) square([5, 80]);

                // v58: removed the dedicated pad for obsolete hole A.
                    screen_side_tabs_2d();
                }
            screen_bottom_tabs_2d();
        }
        screen_stack_holes_2d();
    }
}

module screen_spacer_frame_2d() {
    difference() {
        screen_body_above_floor_v51(2*panel_t)
            union() {
                translate([panel_t, 0]) square([inner_width, screen_opening_s]);
                translate([panel_t, 0]) square([5, screen_spacer_left_end_v51]);
                translate([outer_width-panel_t-5, 0]) square([5, 80]);

                // v58: removed the dedicated pad for obsolete hole A.
            }
        screen_stack_holes_2d();
    }
}

// Only the transverse nut rectangle remains in the laser-cut face profile.
module screen_lr_tnut_cut_2d(axis_s, edge="left") {
    center_x = edge=="left" ? panel_t+screen_tnut_depth_v41
        : outer_width-panel_t-screen_tnut_depth_v41;
    translate([center_x-tnut_nut_thickness/2, axis_s-tnut_nut_af/2])
        square([tnut_nut_thickness,tnut_nut_af]);
}

// Secondary side drilling: not a through-cut channel on the plate face.
// A Ø2.8 bore centered in 3mm stock leaves0.1mm nominal skins on both faces.
module screen_side_screw_bores_v51() {
    for(s=screen_side_tnut_s_v41) {
        translate([panel_t-0.01,s,panel_t/2]) rotate([0,90,0])
            cylinder(d=screen_side_bore_d_v51,h=12.02,$fn=48);
        translate([outer_width-panel_t+0.01,s,panel_t/2]) rotate([0,-90,0])
            cylinder(d=screen_side_bore_d_v51,h=12.02,$fn=48);
    }
}

module screen_rear_carrier_3d_v51() {
    difference() {
        linear_extrude(panel_t) screen_rear_carrier_2d();
        screen_side_screw_bores_v51();
    }
}

module screen_rear_carrier_2d() {
    difference() {
        screen_body_above_floor_v51(screen_carrier_d+panel_t)
            union() {
                translate([panel_t,0]) square([inner_width,screen_opening_s]);
                translate([panel_t,0]) square([5,screen_carrier_left_end_v51]);
                translate([outer_width-panel_t-5,0]) square([5,80]);

                // v58: removed the dedicated pad for obsolete hole A.
                translate([panel_t,16]) square([29.15,12]);
                translate([123.85,16]) square([29.15,12]);
                translate([123.85,67]) square([29.15,12]);
                for (s=screen_side_tnut_s_v41) {
                    screen_lr_tnut_pad_2d(s,"left");
                    screen_lr_tnut_pad_2d(s,"right");
                }
            }
        // Restore the original nine round stack connection holes.
        screen_stack_holes_2d();
        // These three holes attach the display itself, a separate fastening job.
        for (p=screen_case_mounts) translate(p) circle_2d(laser_m25_clearance);
        for (s=screen_side_tnut_s_v41) {
            screen_lr_tnut_cut_2d(s,"left");
            screen_lr_tnut_cut_2d(s,"right");
        }
    }
}

module screen_layer_2d_v51(index=3) {
    if(index==0) screen_outer_frame_2d();
    else if(index==1) screen_structural_frame_2d();
    else if(index==2) screen_spacer_frame_2d();
    else screen_rear_carrier_2d();
}

module laser_cut_version_v51(mode="assembly") {
    if(mode=="screen_layers") {
        for(i=[0:3]) translate([i*175,0,0])
            if(i==3) screen_rear_carrier_3d_v51();
            else linear_extrude(panel_t) screen_layer_2d_v51(i);
    }
    else if(mode=="rear_nut_layer") screen_rear_carrier_3d_v51();
    else laser_cut_version_v50(mode);
}
