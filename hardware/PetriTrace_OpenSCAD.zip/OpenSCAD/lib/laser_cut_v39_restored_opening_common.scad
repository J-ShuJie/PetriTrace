// 第39版共享修正：以第38版全部板件和连接结构为基线，
// 仅恢复第28版中斜屏下方局部竖隔板的大面积避让开口。
//
// 第38版公共文件仍保留了正确的开口坐标，但 geometry_revision >= 2
// 时错误地禁用了它。本文件不修改任何旧版本，只重定义正面板轮廓，
// 让该开口重新参与激光切割。

include <laser_cut_v38_common.scad>

module front_panel_2d() {
    difference() {
        union() {
            translate([panel_t, upper_front_z])
                square([inner_width, inner_height - upper_front_z]);
            translate([panel_t, lower_shelf_z])
                square([work_bay_width, upper_front_z - lower_shelf_z]);
            front_panel_tabs_2d();
        }

        front_panel_divider_upper_slots_2d();

        // 恢复第28版局部竖隔板与斜屏后部相交形成的大开口。
        // 开口只会切到 X=3..98 的局部竖板实体，不会改动右侧设备区。
        translate([
            screen_opening_x,
            recess_front_z_low
        ]) square([
            screen_opening_w,
            recess_front_z_high - recess_front_z_low
        ]);

        // 保留原有屏幕凸柱避让孔。
        translate([screen_pi_boss_x, screen_pi_boss_front_z])
            circle_2d(6.3);

        // 保留上下水平隔板的三组插接槽。
        for (z0 = [lower_shelf_z, upper_shelf_z])
            for (x0 = shelf_front_tab_starts)
                translate([x0, z0])
                    square([finger_w, slot_w]);
    }
}
