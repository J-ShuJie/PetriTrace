// 第44版共享结构：修正第43版对“靠侧边”的理解。
// 两块传感器均沿中央隔板侧布置：
// - 40 x 20 mm TH02 位于内部/正面端，并相对原始孔位旋转 180°；
// - 20 x 20 mm AHT20 位于活动门端，并旋转 90°。

include <laser_cut_v42_door_magnet_common.scad>

sensor_m2_clearance_d_v44 = 2.4;
sensor_edge_margin_v44 = 5;

th02_board_size_v44 = [40, 20];
aht20_board_size_v44 = [20, 20];

// TH02 原始孔位旋转 180°后的局部坐标。
// 单孔端移到 X=0（朝外），双孔端留在靠中央隔板的一侧。
th02_rotated_holes_v44 = [
    [30, 20],
    [30, 0],
    [0, 10]
];

// AHT20 原始左右两孔旋转 90°后，变为前后方向排列。
aht20_rotated_holes_v44 = [
    [10, 0],
    [10, 20]
];

// 两块板的右边缘均距中央隔板净边 5 mm。
// TH02 靠正面/内部端，AHT20 靠活动门端。
th02_board_origin_v44 = [
    panel_t + work_bay_width
        - sensor_edge_margin_v44 - th02_board_size_v44[0],
    panel_t + sensor_edge_margin_v44
];

aht20_board_origin_v44 = [
    panel_t + work_bay_width
        - sensor_edge_margin_v44 - aht20_board_size_v44[0],
    inner_depth
        - sensor_edge_margin_v44 - aht20_board_size_v44[1]
];

module sensor_mount_holes_2d_v44() {
    for (p = th02_rotated_holes_v44)
        translate(th02_board_origin_v44 + p)
            circle_2d(sensor_m2_clearance_d_v44);

    for (p = aht20_rotated_holes_v44)
        translate(aht20_board_origin_v44 + p)
            circle_2d(sensor_m2_clearance_d_v44);
}

module sensor_shelf_part_3d_v44() {
    difference() {
        linear_extrude(panel_t) lower_shelf_2d();
        translate([0, 0, -0.01])
            linear_extrude(panel_t + 0.02)
                sensor_mount_holes_2d_v44();
    }
}

module sensor_board_references_3d_v44(z0 = panel_t) {
    %color([0.23, 0.67, 0.39, 0.72])
        translate([
            th02_board_origin_v44[0],
            th02_board_origin_v44[1],
            z0
        ]) cube([
            th02_board_size_v44[0],
            th02_board_size_v44[1],
            1.6
        ]);

    %color([0.17, 0.55, 0.78, 0.72])
        translate([
            aht20_board_origin_v44[0],
            aht20_board_origin_v44[1],
            z0
        ]) cube([
            aht20_board_size_v44[0],
            aht20_board_size_v44[1],
            1.6
        ]);
}

module sensor_shelf_preview_v44() {
    color([0.43, 0.70, 0.58])
        sensor_shelf_part_3d_v44();
    if (show_sensor_references)
        sensor_board_references_3d_v44();
}

module sensor_hole_cut_at_shelf_v44() {
    translate([0, 0, lower_shelf_z - 0.01])
        linear_extrude(panel_t + 0.02)
            sensor_mount_holes_2d_v44();
}

module enclosure_assembly_v44(system = default_joint_system) {
    difference() {
        enclosure_assembly(system);
        sensor_hole_cut_at_shelf_v44();
    }

    if (show_sensor_references)
        translate([0, 0, lower_shelf_z])
            sensor_board_references_3d_v44();
}

module full_assembly_v44(system = default_joint_system) {
    difference() {
        full_assembly_v42(system);
        sensor_hole_cut_at_shelf_v44();
    }

    if (show_sensor_references)
        translate([0, 0, lower_shelf_z])
            sensor_board_references_3d_v44();
}

module body_with_magnet_v44(system = default_joint_system) {
    difference() {
        body_with_magnet_v42(system);
        sensor_hole_cut_at_shelf_v44();
    }

    if (show_sensor_references)
        translate([0, 0, lower_shelf_z])
            sensor_board_references_3d_v44();
}

module full_flat_layout_v44(system = default_joint_system) {
    difference() {
        full_flat_layout_v42(system);
        translate([290, 280, -0.01])
            linear_extrude(panel_t + 0.02)
                sensor_mount_holes_2d_v44();
    }
}

module laser_cut_version_v44(
    system = default_joint_system,
    mode = default_preview_mode
) {
    if (mode == "assembly")
        full_assembly_v44(system);
    else if (mode == "body")
        body_with_magnet_v44(system);
    else if (mode == "enclosure")
        enclosure_assembly_v44(system);
    else if (mode == "layout")
        full_flat_layout_v44(system);
    else if (mode == "sensor_shelf")
        sensor_shelf_preview_v44();
    else if (mode == "sensor_holes")
        linear_extrude(panel_t) sensor_mount_holes_2d_v44();
    else
        laser_cut_version_v42(system, mode);
}
