// v49: new unequal-leaf hinges; v44 enclosure geometry is the baseline.
// Small-leaf axis distance is ESTIMATED, not a verified hardware dimension.
include <laser_cut_v44_sensor_mount_common.scad>

hinge_centers_z_v49 = [45, 150];
hinge_hole_d_v49 = 3.5;
hinge_small_pitch_v49 = 18;
hinge_large_pitch_v49 = 40;
hinge_barrel_d_v49 = 5;
// 13 mm flat leaf - 6 mm edge-to-hole + 2.5 mm barrel radius.
hinge_small_axis_distance_v49 = 13 - 6 + hinge_barrel_d_v49 / 2;
hinge_large_axis_distance_v49 = 14;
// Continue the external-corner mounting convention of the previous hinge.
// Barrel tangent to both exterior mounting planes; actual hinge offset unverified.
hinge_axis_x_v49 = outer_width + hinge_barrel_d_v49 / 2;
hinge_axis_y_v49 = outer_rear_y + hinge_barrel_d_v49 / 2;
hinge_door_pitch_v49 = large_leaf_on_door_v49
    ? hinge_large_pitch_v49 : hinge_small_pitch_v49;
hinge_side_pitch_v49 = large_leaf_on_door_v49
    ? hinge_small_pitch_v49 : hinge_large_pitch_v49;
hinge_door_x_v49 = hinge_axis_x_v49 - (large_leaf_on_door_v49
    ? hinge_large_axis_distance_v49 : hinge_small_axis_distance_v49);
hinge_side_y_v49 = hinge_axis_y_v49 - (large_leaf_on_door_v49
    ? hinge_small_axis_distance_v49 : hinge_large_axis_distance_v49);
function hinge_hole_heights_v49(pitch) = [
    for (center = hinge_centers_z_v49)
        for (offset = [-pitch / 2, pitch / 2]) center + offset
];

// Override only the right-side hardware cutouts; Crowtail holes are unchanged.
module right_side_hardware_holes_2d() {
    crowtail_y0 = (90 - crowtail_board_size[0]) / 2;
    crowtail_z0 = inner_height - 2.5 - crowtail_board_size[1];
    for (point = crowtail_mounting_hole_centers)
        translate([crowtail_y0 + point[0], crowtail_z0 + point[1]])
            circle_2d(laser_m25_clearance);
    for (z = hinge_hole_heights_v49(hinge_side_pitch_v49))
        translate([hinge_side_y_v49, z]) circle_2d(hinge_hole_d_v49);
}

// Replace the old hinge holes, rather than adding new holes beside them.
// Handle tabs, handle screws and magnet screws retain the v42 definitions.
module door_panel_2d_v42() {
    difference() {
        square([outer_width, inner_height]);
        for (z = hinge_hole_heights_v49(hinge_door_pitch_v49))
            translate([hinge_door_x_v49, z]) circle_2d(hinge_hole_d_v49);
        for (z = handle_inner_tab_global_z_v42)
            translate([handle_blade_x0_v42 + (panel_t - slot_w) / 2, z])
                square([slot_w, finger_w]);
        for (z = handle_door_lock_global_z_v42)
            translate([handle_blade_x0_v42 + panel_t / 2, z])
                circle_2d(tnut_screw_d);
        magnet_plate_bolt_holes_2d_v42();
    }
}

module laser_cut_version_v49(mode = "assembly") {
    if (mode == "door_2d") door_panel_2d_v42();
    else if (mode == "right_side_2d") side_panel_2d(true, joint_system);
    else if (mode == "holes_2d") {
        for (z = hinge_hole_heights_v49(hinge_door_pitch_v49))
            translate([hinge_door_x_v49, z]) circle_2d(hinge_hole_d_v49);
        for (z = hinge_hole_heights_v49(hinge_side_pitch_v49))
            translate([200 + hinge_side_y_v49, z]) circle_2d(hinge_hole_d_v49);
    }
    else laser_cut_version_v44(joint_system, mode);
}
