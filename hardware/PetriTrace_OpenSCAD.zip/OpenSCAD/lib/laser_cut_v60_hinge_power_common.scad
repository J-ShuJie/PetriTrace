// v60: measured unequal-leaf hinges; alternative USB-C cable pass-through panels.
hinge_A_v60 = 9.5;
hinge_B_v60 = 5.75;
hinge_actual_bore_v60 = 5;
hinge_large_flat_width_v60 = 19;
hinge_small_flat_width_v60 = 12;
include <laser_cut_v59_fit_common.scad>
include <laser_cut_v60_profile_bases.scad>
hinge_barrel_d_v49 = 6;
hinge_large_pitch_v49 = 40;
hinge_small_pitch_v49 = 17;
hinge_hole_d_v49 = 4.5; // wood clearance for M4; actual metal bore is 5mm
hinge_large_axis_distance_v49 = hinge_large_flat_width_v60
    +hinge_barrel_d_v49/2-hinge_A_v60;
hinge_small_axis_distance_v49 = hinge_small_flat_width_v60
    +hinge_barrel_d_v49/2-hinge_B_v60;
// Preserve the external 90-degree corner mount, with the new 6mm barrel.
// Axis (159,101); door holes X146.5; fixed-side holes Y91.75.
hinge_axis_x_v49 = outer_width+hinge_barrel_d_v49/2;
hinge_axis_y_v49 = outer_rear_y+hinge_barrel_d_v49/2;

power_hole_size_v60 = [13,8];
power_hole_radius_v60 = 1;
power_side_center_v60 = [25,18]; // Y/Z: lower bay, in front of rear magnet
power_door_center_v60 = [65,18]; // X/Z: below the 25mm shelf, clear of handle
module power_hole_2d_v60(center) {
    translate(center) offset(r=power_hole_radius_v60)
        square([power_hole_size_v60[0]-2*power_hole_radius_v60,
                power_hole_size_v60[1]-2*power_hole_radius_v60],center=true);
}

// The fixed-side M4 inner head is near the back edge and would enter the door.
// Closed 4.5 x 9mm reliefs contain an 8mm-diameter, 3mm-high head and clearance.
// They are at the RIGHT hinge edge, not the removed LEFT handle-edge notches.
hinge_side_head_d_v60 = 8;
hinge_side_head_h_v60 = 3;
module hinge_head_reliefs_door_2d_v60() {
    for(z=hinge_hole_heights_v49(hinge_side_pitch_v49))
        translate([outer_width-panel_t-hinge_side_head_h_v60-0.5,z-4.5])
            square([hinge_side_head_h_v60+1.5,9]);
}
module door_panel_solid_v60() {
    difference() {door_panel_base_v60();hinge_head_reliefs_door_2d_v60();}
}
module door_panel_power_v60() {
    difference() {door_panel_solid_v60();power_hole_2d_v60(power_door_center_v60);}
}
module side_panel_power_v60() {
    difference() {side_panel_base_v60(false,joint_system);
        power_hole_2d_v60(power_side_center_v60);}
}
module door_panel_2d_v42() {
    if(power_exit_v60=="door") door_panel_power_v60();
    else door_panel_solid_v60();
}
module side_panel_2d(is_right=false,system=default_joint_system) {
    difference() {
        side_panel_base_v60(is_right,system);
        if(!is_right && power_exit_v60=="side")
            power_hole_2d_v60(power_side_center_v60);
    }
}

// Installation envelopes. Metal leaf thickness is illustrative (1mm), not measured.
hinge_leaf_t_reference_v60 = 1;
module hinge_large_leaf_2d_v60(zc) {
    difference() {
        translate([outer_width-hinge_large_flat_width_v60,zc-25])
            square([hinge_large_flat_width_v60+hinge_barrel_d_v49/2,50]);
        translate([outer_width-12,zc-13.2]) square([16,26.4]);
        for(dz=[-20,20]) translate([hinge_door_x_v49,zc+dz])
            circle(d=hinge_actual_bore_v60,$fn=48);
    }
}
module hinge_small_leaf_2d_v60(zc) {
    difference() {
        translate([outer_rear_y-hinge_small_flat_width_v60,zc-13])
            square([hinge_small_flat_width_v60+hinge_barrel_d_v49/2,26]);
        for(dz=[-8.5,8.5]) translate([hinge_side_y_v49,zc+dz])
            circle(d=hinge_actual_bore_v60,$fn=48);
    }
}
module hinge_hardware_reference_v60() {
    for(zc=hinge_centers_z_v49) {
        color([0.8,0.67,0.3])
            multmatrix([[1,0,0,0],[0,0,1,outer_rear_y],[0,1,0,0],[0,0,0,1]])
            linear_extrude(hinge_leaf_t_reference_v60)
            hinge_large_leaf_2d_v60(zc);
        color([0.4,0.7,0.78])
            multmatrix([[0,0,1,outer_width],[1,0,0,0],[0,1,0,0],[0,0,0,1]])
            linear_extrude(hinge_leaf_t_reference_v60)
            hinge_small_leaf_2d_v60(zc);
        color([0.65,0.68,0.72]) translate([hinge_axis_x_v49,hinge_axis_y_v49,zc-25])
            cylinder(d=hinge_barrel_d_v49,h=50,$fn=64);
    }
}
// Reference fastener heads on the inside of the fixed side wall.
module hinge_side_heads_v60() {
    for(z=hinge_hole_heights_v49(hinge_side_pitch_v49))
        translate([outer_width-panel_t-hinge_side_head_h_v60,
                   hinge_side_y_v49,z]) rotate([0,90,0])
            cylinder(d=hinge_side_head_d_v60,h=hinge_side_head_h_v60,$fn=48);
}
module laser_cut_version_v60(mode="assembly") {
    if(mode=="power_options") {
        linear_extrude(panel_t) door_panel_power_v60();
        translate([205,0,0]) linear_extrude(panel_t) side_panel_power_v60();
    }
    else if(mode=="door_solid") linear_extrude(panel_t) door_panel_solid_v60();
    else if(mode=="door_power") linear_extrude(panel_t) door_panel_power_v60();
    else if(mode=="side_solid") linear_extrude(panel_t) side_panel_base_v60(false,joint_system);
    else if(mode=="side_power") linear_extrude(panel_t) side_panel_power_v60();
    else if(mode=="hinge_detail") {
        color([0.7,0.75,0.83,0.6]) intersection() {
            union(){side_panel_3d(outer_width-panel_t,true,joint_system);
                xz_panel_3d(door_inner_y_v42) door_panel_2d_v42();}
            translate([130,80,15]) cube([36,26,62]);
        }
        %hinge_hardware_reference_v60();
        %color("orange") hinge_side_heads_v60();
    }
    else {
        laser_cut_version_v58(mode);
        if(mode=="assembly" && show_hinge_reference_v60)
            %hinge_hardware_reference_v60();
    }
}
