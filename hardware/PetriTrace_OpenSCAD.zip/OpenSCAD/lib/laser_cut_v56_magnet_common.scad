// v56: change only the rear tongue positions and their derived wall receivers.
// Retain the 36mm body, all screw/nut positions and v55 closed door reliefs.
include <laser_cut_v55_magnet_common.scad>
// Each 8mm tongue starts at a body end and extends inward to a screw axis.
// Overall body Z=79.5..115.5; insertion depth is still 3mm.
magnet_back_tabs_v53 = [[79.5,8],[107.5,8]];

// Match the ordinary enclosure fit: 3mm board into a centered 2.9mm slot.
// Tongue-height direction is nominally equal, with no extra clearance.
// Screw holes, nut pockets and moving-part gaps keep their existing dimensions.
module magnet_wall_slots_2d_v53() {
    for(pair=[[body_magnet_carrier_y_v42,magnet_front_tabs_v53],
              [body_magnet_back_y_v42,magnet_back_tabs_v53]])
        for(t=pair[1]) translate([pair[0]+(panel_t-slot_w)/2,t[0]])
            square([slot_w,t[1]]);
}
