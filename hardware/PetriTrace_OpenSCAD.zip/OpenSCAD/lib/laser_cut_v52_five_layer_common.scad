// Fifth rear reinforcement for Raspberry Pi Touch Display 2, 5-inch.
// Screen mounting plane stays at d=6 (9mm from the outer face at d=-3).
include <laser_cut_v51_screen_common.scad>

screen_fifth_d_v52 = screen_carrier_d + panel_t; // d=9..12
screen_fifth_bottom_s_v52 = screen_min_s_v51(screen_fifth_d_v52+panel_t);
screen_fifth_front_gap_v52 = 0.5;
screen_fifth_left_end_v52 =
    (screen_base-screen_fifth_front_gap_v52
        - screen_b*(screen_fifth_d_v52+panel_t))/screen_a;

// Restore the full in-plane screw access in the fourth layer.
module screen_lr_tnut_cut_2d(axis_s, edge="left") {
    center_x = edge=="left" ? panel_t+screen_tnut_depth_v41
        : outer_width-panel_t-screen_tnut_depth_v41;
    translate([center_x-tnut_nut_thickness/2,axis_s-tnut_nut_af/2])
        square([tnut_nut_thickness,tnut_nut_af]);
    if(edge=="left")
        translate([panel_t-0.01,axis_s-tnut_screw_d/2])
            square([center_x-panel_t+0.01,tnut_screw_d]);
    else
        translate([center_x,axis_s-tnut_screw_d/2])
            square([outer_width-panel_t-center_x+0.01,tnut_screw_d]);
}

// Existing v38 assembly/flat-layout hook: no secondary side drilling in v52.
module screen_rear_carrier_3d_v51() {
    linear_extrude(panel_t) screen_rear_carrier_2d();
}

module screen_fifth_positive_2d_v52() {
    difference() {
        screen_body_above_floor_v51(screen_fifth_d_v52+panel_t)
            union() {
                translate([panel_t,0]) square([inner_width,screen_opening_s]);
                translate([panel_t,0]) square([5,58]);
                translate([outer_width-panel_t-5,0]) square([5,80]);

                // v58: removed the dedicated pad for obsolete hole A.
                translate([panel_t,16]) square([29.15,12]);
                translate([123.85,16]) square([29.15,12]);
                translate([123.85,67]) square([29.15,12]);
                for(s=screen_side_tnut_s_v41) {
                    screen_lr_tnut_pad_2d(s,"left");
                    screen_lr_tnut_pad_2d(s,"right");
                }
            }
        // Only the left half faces the lower front-panel material.
        translate([-10,screen_fifth_left_end_v52])
            square([outer_width/2+10,screen_length+20]);
    }
}

module screen_fifth_nut_slots_2d_v52() {
    for(s=screen_side_tnut_s_v41)
        for(x=[panel_t+screen_tnut_depth_v41,
            outer_width-panel_t-screen_tnut_depth_v41])
            translate([x-tnut_nut_thickness/2,s-tnut_nut_af/2])
                square([tnut_nut_thickness,tnut_nut_af]);
}

module screen_fifth_2d_v52() {
    difference() {
        screen_fifth_positive_2d_v52();
        screen_stack_holes_2d();
        for(p=screen_case_mounts) translate(p) circle_2d(laser_m25_clearance);
        screen_fifth_nut_slots_2d_v52();
        // Bottom circles would leave only~0.07mm of material after trimming.
        // Open them to the new edge instead, retaining all original screw axes.
        for(x=[20,136])
            translate([x-laser_m25_clearance/2,screen_fifth_bottom_s_v52-0.01])
                square([laser_m25_clearance,5-screen_fifth_bottom_s_v52+0.01]);
        // The left upper functional hole becomes an edge relief where the new
        // front-panel trim meets it. The four dedicated stack fasteners stay closed.
    }
}

module screen_stack_3d() {
    color([0.18,0.22,0.30]) on_sloped_front()
        translate([0,0,screen_front_outer_d]) linear_extrude(panel_t) screen_outer_frame_2d();
    color([0.34,0.39,0.46]) on_sloped_front()
        linear_extrude(panel_t) screen_structural_frame_2d();
    color([0.40,0.45,0.52]) on_sloped_front()
        translate([0,0,panel_t]) linear_extrude(panel_t) screen_spacer_frame_2d();
    color([0.64,0.44,0.18]) on_sloped_front()
        translate([0,0,screen_carrier_d]) linear_extrude(panel_t) screen_rear_carrier_2d();
    color([0.24,0.63,0.57]) on_sloped_front()
        translate([0,0,screen_fifth_d_v52]) linear_extrude(panel_t) screen_fifth_2d_v52();
}

module full_flat_layout_v44(system=default_joint_system) {
    difference() {
        union() {
            full_flat_layout_v42(system);
            translate([700,445,0]) linear_extrude(panel_t) screen_fifth_2d_v52();
        }
        translate([290,280,-0.01]) linear_extrude(panel_t+0.02) sensor_mount_holes_2d_v44();
    }
}

module laser_cut_version_v52(mode="assembly") {
    if(mode=="screen_layers") {
        for(i=[0:4]) translate([i*175,0,0])
            if(i==4) linear_extrude(panel_t) screen_fifth_2d_v52();
            else linear_extrude(panel_t) screen_layer_2d_v51(i);
    }
    else if(mode=="fifth_layer") linear_extrude(panel_t) screen_fifth_2d_v52();
    else if(mode=="fourth_layer") linear_extrude(panel_t) screen_rear_carrier_2d();
    else laser_cut_version_v51(mode);
}
