// v54: compact body while increasing the material beyond the two T slots.
include <laser_cut_v53_magnet_common.scad>
body_magnet_height_v53 = 38;
body_magnet_side_lock_z_v42 = [87.5,107.5];
magnet_back_tabs_v53 = [[79.5,5],[110.5,5]];

// The relocated side nuts reach into the door carrier in the closed position.
// Open these small reliefs to the edges rather than leave a 1.4mm fragile bridge.
module magnet_door_nut_relief_2d_v54() {
    translate([10-magnet_nut_x_v53/2,magnet_plate_z0_v42-0.01])
        square([magnet_nut_x_v53,
            body_magnet_side_lock_z_v42[0]+magnet_nut_z_v53/2-magnet_plate_z0_v42+0.01]);
    translate([10-magnet_nut_x_v53/2,
            body_magnet_side_lock_z_v42[1]-magnet_nut_z_v53/2])
        square([magnet_nut_x_v53,
            magnet_plate_z0_v42+magnet_plate_h_v42-
            (body_magnet_side_lock_z_v42[1]-magnet_nut_z_v53/2)+0.01]);
}
module door_magnet_carrier_2d_v42() {
    difference() {
        translate([magnet_plate_x0_v42,magnet_plate_z0_v42])
            square([magnet_plate_w_v42,magnet_plate_h_v42]);
        magnet_window_2d_v42();
        magnet_plate_bolt_holes_2d_v42();
        magnet_door_nut_relief_2d_v54();
    }
}
