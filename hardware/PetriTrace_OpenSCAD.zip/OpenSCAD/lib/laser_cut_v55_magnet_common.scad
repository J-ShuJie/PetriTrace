// v55: partial tab alignment forms one stepped wall receiver.
include <laser_cut_v54_magnet_common.scad>
body_magnet_height_v53 = 36;
magnet_back_tabs_v53 = [[90.5,5],[99.5,5]];

// Only the tapered outer portion of each hex nut reaches the door carrier.
// Assumed nut: 5mm across flats (flats parallel to Y), 2mm along X.
// At the door face, Y offset from nut axis is 1.8mm:
// occupied Z height = 2*(5-sqrt(3)*1.8) = 3.7646mm.
// Use a 4mm closed relief instead of the former open-edge clearance.
magnet_door_nut_relief_h_v55 = 4.0;
module magnet_door_nut_relief_2d_v54() {
    for(z=body_magnet_side_lock_z_v42)
        translate([10-magnet_nut_x_v53/2,z-magnet_door_nut_relief_h_v55/2])
            square([magnet_nut_x_v53,magnet_door_nut_relief_h_v55]);
}
