// 第41版共享修正：在第40版M2.5 T槽基础上闭合外围承力路径。
// 1. 三角前伸区与底板的单侧锁紧改为左右各一处；
// 2. 正面竖直外板与左右侧板各增加两处T槽；
// 3. 斜屏最后方承载层与左右侧板各增加两处T槽；
// 4. 斜屏叠层左右各保留两处贯通孔，用长M2.5螺丝夹紧整组叠层。

include <laser_cut_v40_tnut_m25_common.scad>

front_side_tnut_z_v41 = [115, 175];
screen_side_tnut_s_v41 = [25, 45];

// 原有五个功能孔全部原样保留，不把它们冒充新增的结构固定孔。
// 另设四个封闭圆孔供长螺丝贯穿叠层：左s=15/35，右s=15/55。
// 新孔中心避开可视开口，M2.5垫片也能完整落在8 mm外框上。
screen_stack_holes = [
    [20, 5], [136, 5],
    [7.5, 50],
    [150.5, 35], [150.5, 65],
    [5.5, 15], [5.5, 35],
    [150.5, 15], [150.5, 55]
];

// 正面板左右边缘的T形螺母槽。正面板从侧板内表面开始，
// 所以通道从x=panel_t或x=outer_width-panel_t进入，而不是从外轮廓进入。
module front_lr_tnut_cut_2d(axis_z, edge = "left") {
    center_x = edge == "left"
        ? panel_t + tnut_axis_from_edge
        : outer_width - panel_t - tnut_axis_from_edge;

    translate([
        center_x - tnut_nut_thickness / 2,
        axis_z - tnut_nut_af / 2
    ]) square([tnut_nut_thickness, tnut_nut_af], center = false);

    if (edge == "left")
        translate([panel_t - 0.01, axis_z - tnut_screw_d / 2])
            square([
                center_x - panel_t + 0.01,
                tnut_screw_d
            ], center = false);
    else
        translate([center_x, axis_z - tnut_screw_d / 2])
            square([
                outer_width - panel_t - center_x + 0.01,
                tnut_screw_d
            ], center = false);
}

// 斜屏后承载层左右边缘的T槽。局部加宽块位于现有指接齿之间，
// 螺丝从侧板外侧横向进入，螺母被锁在最后方承载层内。
screen_tnut_depth_v41 = 7;

module screen_lr_tnut_pad_2d(axis_s, edge = "left") {
    if (edge == "left")
        translate([panel_t, axis_s - 5])
            square([12, 10], center = false);
    else
        translate([outer_width - panel_t - 12, axis_s - 5])
            square([12, 10], center = false);
}

module screen_lr_tnut_cut_2d(axis_s, edge = "left") {
    center_x = edge == "left"
        ? panel_t + screen_tnut_depth_v41
        : outer_width - panel_t - screen_tnut_depth_v41;

    translate([
        center_x - tnut_nut_thickness / 2,
        axis_s - tnut_nut_af / 2
    ]) square([tnut_nut_thickness, tnut_nut_af], center = false);

    if (edge == "left")
        translate([panel_t - 0.01, axis_s - tnut_screw_d / 2])
            square([
                center_x - panel_t + 0.01,
                tnut_screw_d
            ], center = false);
    else
        translate([center_x, axis_s - tnut_screw_d / 2])
            square([
                outer_width - panel_t - center_x + 0.01,
                tnut_screw_d
            ], center = false);
}

// 保留第39版大开口和第40版顶边两处T槽，再加入左右侧锁紧。
module front_panel_2d() {
    difference() {
        union() {
            translate([panel_t, upper_front_z])
                square([inner_width, inner_height - upper_front_z]);
            translate([panel_t, lower_shelf_z])
                square([work_bay_width, upper_front_z - lower_shelf_z]);
            front_panel_tabs_2d();
        }

        front_panel_divider_upper_slots_2d();

        translate([
            screen_opening_x,
            recess_front_z_low
        ]) square([
            screen_opening_w,
            recess_front_z_high - recess_front_z_low
        ]);

        translate([screen_pi_boss_x, screen_pi_boss_front_z])
            circle_2d(6.3);

        for (z0 = [lower_shelf_z, upper_shelf_z])
            for (x0 = shelf_front_tab_starts)
                translate([x0, z0])
                    square([finger_w, slot_w]);

        for (x = front_top_tnut_x_v40)
            tnut_edge_cut_2d(x, "top");

        for (z = front_side_tnut_z_v41) {
            front_lr_tnut_cut_2d(z, "left");
            front_lr_tnut_cut_2d(z, "right");
        }
    }
}

// 两块侧板都获得三角前伸区底部T槽、正面板横向通孔，
// 以及位于斜边既有指接齿间隙中的两处斜屏横向通孔。
module side_panel_2d(is_right = false, system = default_joint_system) {
    difference() {
        if (active_geometry_revision >= 2)
            union() {
                polygon(points = [
                    [-screen_base, 0],
                    [inner_depth, 0],
                    [inner_depth, inner_height],
                    [0, inner_height],
                    [0, screen_rise]
                ]);
                side_bottom_fingers_2d();
                side_top_fingers_2d();
            }
        else
            polygon(points = [
                [-screen_base, 0],
                [inner_depth, 0],
                [inner_depth, inner_height],
                [0, inner_height],
                [0, screen_rise]
            ]);

        if (active_geometry_revision < 2) {
            legacy_side_bottom_notches_2d();
            legacy_side_top_notches_2d();
        }

        side_front_notches_2d(is_right);
        for (s0 = screen_joint_starts)
            sloped_edge_notch_2d(s0);
        if (!is_right)
            side_shelf_slots_2d();

        if (system == "wood")
            wood_side_holes_2d();
        else if (system == "tnut") {
            for (y = tnut_axis_y) {
                tnut_edge_cut_2d(y, "bottom");
                tnut_edge_cut_2d(y, "top");
            }

            // 左右三角前伸区与底板均锁紧。
            tnut_edge_cut_2d(right_triangle_bottom_tnut_y_v40,
                "bottom");

            // 正面竖板位于y=0..panel_t，横向螺丝取其厚度中心。
            for (z = front_side_tnut_z_v41)
                translate([panel_t / 2, z])
                    circle_2d(tnut_screw_d);

            // 横向T槽位于最后方承载层d=screen_carrier_d..+panel_t；
            // 孔心取该层厚度中心，避免让侧板孔贴着斜边崩裂。
            for (s = screen_side_tnut_s_v41)
                translate(recess_global_point(
                    s,
                    screen_carrier_d + panel_t / 2
                ))
                    circle_2d(tnut_screw_d);
        }

        if (is_right)
            right_side_hardware_holes_2d();
    }
}

// 底板在左右三角侧板中心线处各增加一枚M2.5通孔。
module bottom_panel_2d(system = default_joint_system) {
    difference() {
        if (active_geometry_revision >= 2)
            translate([0, -screen_base])
                square([outer_width, outer_rear_y + screen_base]);
        else
            union() {
                translate([panel_t, -screen_base])
                    square([inner_width,
                        outer_rear_y + screen_base]);
                legacy_side_tabs_for_horizontal_panel_2d(true);
            }

        if (active_geometry_revision >= 2)
            side_finger_receiver_notches_2d(true);
        divider_receiver_slots_2d();
        screen_bottom_slots_2d();
        main_fastener_holes_horizontal_2d(system);

        if (system == "tnut")
            for (x = [panel_t / 2, outer_width - panel_t / 2])
                translate([x, right_triangle_bottom_tnut_y_v40])
                    circle_2d(tnut_screw_d);
    }
}

// 最后方承载层承担与侧板的横向T槽锁紧；贯通孔仍由
// screen_stack_holes_2d()同时切入外框、结构层、间隔层和后承载层，
// 使长螺丝把四层夹成整体，而不是让最后一层单独吃力。
module screen_rear_carrier_2d() {
    difference() {
        union() {
            translate([panel_t, 0])
                square([inner_width, screen_opening_s]);
            translate([panel_t, 0]) square([5, 60]);
            translate([outer_width - panel_t - 5, 0]) square([5, 80]);
            translate([panel_t, 44]) square([9, 12]);
            translate([panel_t, 16]) square([29.15, 12]);
            translate([123.85, 16]) square([29.15, 12]);
            translate([123.85, 67]) square([29.15, 12]);

            for (s = screen_side_tnut_s_v41) {
                screen_lr_tnut_pad_2d(s, "left");
                screen_lr_tnut_pad_2d(s, "right");
            }
        }

        screen_stack_holes_2d();
        for (p = screen_case_mounts)
            translate(p) circle_2d(laser_m25_clearance);

        for (s = screen_side_tnut_s_v41) {
            screen_lr_tnut_cut_2d(s, "left");
            screen_lr_tnut_cut_2d(s, "right");
        }
    }
}
