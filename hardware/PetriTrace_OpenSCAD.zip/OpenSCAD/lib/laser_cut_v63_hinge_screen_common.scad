// v63: one model with a matched alternate side/door pair. Units: mm.
include <laser_cut_v62_power_handle_support_common.scad>

// Measurements are WOOD EDGE to the far straight METAL LEAF EDGE.
// A=9.5 (large leaf), B=5.75 (small leaf); all vertical pitches stay unchanged.
hinge_door_x_v49 = outer_width-9.5;
hinge_side_y_v49 = inner_depth-(11.5-hinge_B_v60);
function hinge_door_x_v63() = $hinge_variant_v63=="alternate"
    ? outer_width-(23-hinge_A_v60) : hinge_door_x_v49;
function hinge_side_y_v63() = $hinge_variant_v63=="alternate"
    ? inner_depth-(15.5-hinge_B_v60) : hinge_side_y_v49;

module right_side_hardware_holes_2d() {
    crowtail_y0=(90-crowtail_board_size[0])/2;
    crowtail_z0=inner_height-2.5-crowtail_board_size[1];
    for(p=crowtail_mounting_hole_centers)
        translate([crowtail_y0+p[0],crowtail_z0+p[1]]) circle_2d(laser_m25_clearance);
    for(z=hinge_hole_heights_v49(hinge_side_pitch_v49))
        translate([hinge_side_y_v63(),z]) circle_2d(hinge_hole_d_v49);
}
module door_panel_base_v60() {
    difference() {
        square([outer_width,inner_height]);
        for(z=hinge_hole_heights_v49(hinge_door_pitch_v49))
            translate([hinge_door_x_v63(),z]) circle_2d(hinge_hole_d_v49);
        for(z=handle_inner_tab_global_z_v42)
            translate([handle_blade_x0_v42+(panel_t-slot_w)/2,z]) square([slot_w,finger_w]);
        for(z=handle_door_lock_global_z_v42)
            translate([handle_blade_x0_v42+panel_t/2,z]) circle_2d(tnut_screw_d);
        door_magnet_bolt_holes_2d_v58();
    }
}

// Remove only the two bottom axes from ALL five layers.
screen_stack_holes = [[150.5,35],[150.5,65],
    [5.5,15],[5.5,35],[150.5,15],[150.5,55]];
screen_front_head_d_v63 = 4;
module screen_outer_frame_2d() {
    difference() {
        square([outer_width,screen_length]);
        translate([screen_opening_x,screen_opening_s]) square([screen_opening_w,screen_opening_l]);
        for(p=screen_stack_holes) translate(p) circle_2d(screen_front_head_d_v63);
    }
}
module screen_fifth_2d_v52() {
    difference() {
        screen_fifth_positive_2d_v52();
        screen_stack_holes_2d();
        for(p=screen_case_mounts) translate(p) circle_2d(laser_m25_clearance);
        screen_fifth_nut_slots_2d_v52();
        // No bottom U cuts: both obsolete bottom screw passages are fully filled.
    }
}
module spare_pair_v63() {
    let($hinge_variant_v63="alternate") {
        linear_extrude(panel_t) side_panel_2d(true,joint_system);
        translate([145,0,0]) linear_extrude(panel_t) door_panel_power_v60();
    }
}
module laser_cut_version_v63(mode="assembly") {
    if(mode=="assembly_with_spares") {
        laser_cut_version_v62("assembly");
        translate([205,0,0]) spare_pair_v63();
    }
    else if(mode=="spare_pair") spare_pair_v63();
    else if(mode=="right_side") linear_extrude(panel_t) side_panel_2d(true,joint_system);
    else laser_cut_version_v62(mode);
}
