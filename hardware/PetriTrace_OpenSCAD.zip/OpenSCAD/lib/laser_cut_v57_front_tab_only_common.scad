// v57: independent copy of v56, removing only the six large front-panel locks.
include <laser_cut_v56_magnet_common.scad>

// Empty both shared axis lists so the front T slots, matching round holes in
// both side walls / top panel, and their top nut preview references all disappear.
// Finger joints and all unrelated enclosure fasteners retain their v56 geometry.
front_side_tnut_z_v41 = [];
front_top_tnut_x_v40 = [];
