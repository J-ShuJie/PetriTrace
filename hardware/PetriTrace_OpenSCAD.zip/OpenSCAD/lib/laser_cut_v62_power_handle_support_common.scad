// v62 changes only the agreed handle width, fifth-layer slot length and power routing.
// Define new datums before the inherited assignments that reference them.
rpi_back_gap_v62 = 3;
rpi_bottom_v62 = 5;
rpi_rear_board_edge_v62 = 73;
rpi_usb_u_v62 = 11.2;
rpi_usb_axis_from_back_v62 = 3.016; // official STEP mouth sections, three Y cuts agree
rpi_pcb_height_v62 = 1.336; // PCB with copper layers, not the old 1.6mm placeholder
screen_fifth_slot_length_v62 = 4.5;
include <laser_cut_v61_tight_hinge_common.scad>

handle_return_w_v42 = 18; // Only the 13mm edge grows; height stays155, blade stays14.

// Keep short edge2.2, all nut centres and the entire fourth layer unchanged.
// The two ends of each fifth-layer slot gain0.25mm of support material.
module screen_fifth_nut_slots_2d_v52() {
    for(s=screen_side_tnut_s_v41)
        for(x=[panel_t+screen_tnut_depth_v41,
               outer_width-panel_t-screen_tnut_depth_v41])
            translate([x-fit_nut_pocket_axial_v59/2,
                       s-screen_fifth_slot_length_v62/2])
                square([fit_nut_pocket_axial_v59,screen_fifth_slot_length_v62]);
}

power_hole_size_v60 = [8,13];
power_door_center_v60 = [divider_x+panel_t+rpi_back_gap_v62+rpi_usb_axis_from_back_v62,
                         rpi_bottom_v62+rpi_usb_u_v62];

// Both outer side walls now have NO power pass-through. The old legacy mode also
// returns the solid wall, so an inherited exporter cannot recreate the wrong hole.
module side_panel_power_v60() {side_panel_base_v60(false,joint_system);}
module side_panel_2d(is_right=false,system=default_joint_system) {
    side_panel_base_v60(is_right,system);
}
module door_panel_power_v60() {
    difference() {
        door_panel_solid_v60();
        power_hole_2d_v60(power_door_center_v60);
    }
}

// Official PCB coordinates (u,v,w) map to (X,Y,Z) with component side facing
// the small electronics bay (+X), USB-C facing the door (+Y), board end down.
module rpi_to_enclosure_v62() {
    multmatrix([[0,0,1,divider_x+panel_t+rpi_back_gap_v62],
                [0,-1,0,rpi_rear_board_edge_v62],
                [1,0,0,rpi_bottom_v62],[0,0,0,1]]) children();
}
module rpi_installation_reference_v62() {
    color([0.13,0.53,0.31]) rpi_to_enclosure_v62() difference() {
        cube([85,56,rpi_pcb_height_v62]);
        for(p=rpi5_mounting_hole_centers)
            translate([p[0],p[1],-.01]) cylinder(d=2.7,h=1.36,$fn=32);
    }
    // Three representative underside envelopes, not a complete electronics model.
    color([.28,.30,.33]) rpi_to_enclosure_v62() {
        translate([15.7,32,-1.45]) cube([1.6,3,1.45]);
        translate([2.25,22.11,-1.42]) cube([11.4,11.95,1.42]);
    }
    color([.8,.65,.28])
        for(p=rpi5_mounting_hole_centers)
            translate([divider_x+panel_t,rpi_rear_board_edge_v62-p[1],rpi_bottom_v62+p[0]])
                rotate([0,90,0]) difference() {
                    cylinder(d=5.5,h=rpi_back_gap_v62,$fn=32);
                    translate([0,0,-.01])cylinder(d=2.5,h=rpi_back_gap_v62+.02,$fn=32);
                }
    // Simplified socket with a centred, vertically oriented front opening.
    color([.7,.72,.76]) rpi_to_enclosure_v62() difference() {
        translate([6.73,-1.2,1.436])cube([8.94,7.32,3.16]);
        translate([7.03,-1.21,1.736])cube([8.34,3,2.56]);
    }
}
module rpi_plug_envelope_v62() {
    // Maximum published 27W overmould cross-section7.3 x12.3, swept from the
    // socket mouth to beyond the door. This is an insertion clearance envelope,
    // NOT the installed cable's shape or a claim about metal-tip insertion depth.
    translate([power_door_center_v60[0]-7.3/2,74.2,power_door_center_v60[1]-12.3/2])
        cube([7.3,26.8,12.3]);
}
module laser_cut_version_v62(mode="assembly") {
    if(mode=="power_detail") {
        color([.6,.7,.8,.4]) intersection() {
            union(){yz_panel_3d(divider_x)central_divider_2d();
                xz_panel_3d(95)door_panel_power_v60();}
            translate([96,68,0])cube([30,33,38]);
        }
        rpi_installation_reference_v62();
        %color([.88,.45,.16])rpi_plug_envelope_v62();
    }
    else if(mode=="power_options") {
        linear_extrude(panel_t)door_panel_power_v60();
        translate([175,0,0])linear_extrude(panel_t)door_panel_solid_v60();
    }
    else {
        laser_cut_version_v60(mode);
        if(mode=="assembly" && show_rpi_reference_v62)
            %rpi_installation_reference_v62();
    }
}
