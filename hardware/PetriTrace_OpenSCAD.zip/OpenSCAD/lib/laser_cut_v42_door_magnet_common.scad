// 第42版共享结构：在第41版外围锁紧基础上补回磁吸，并将第29版
// 活动门/J形把手拆成可激光切割、可拆卸的板件组件。

include <laser_cut_v41_perimeter_lock_common.scad>

// 原第27~29版门与磁铁基准。
door_inner_y_v42 = inner_depth;                 // 95
door_outer_y_v42 = outer_rear_y;                // 98
door_hinge_hole_x_v42 = 150.55;
door_hinge_hole_z_v42 = [36, 54, 141, 159];

magnet_nominal_v42 = [5, 2, 10];               // X/Y/Z
magnet_window_v42 = [5.3, 10.3];               // X/Z
magnet_center_v42 = [10.5, inner_height / 2];   // X/Z
magnet_plate_x0_v42 = 3;
magnet_plate_w_v42 = 18;
magnet_plate_z0_v42 = magnet_center_v42[1] - 14;
magnet_plate_h_v42 = 28;
magnet_plate_bolt_x_v42 = 17;
magnet_plate_bolt_z_v42 = [87.5, 107.5];

body_magnet_face_y_v42 = 91.3;
body_magnet_carrier_y_v42 = body_magnet_face_y_v42 - panel_t;
body_magnet_back_y_v42 = body_magnet_carrier_y_v42 - panel_t;
body_magnet_side_lock_z_v42 = [86.5, 108.5];
body_magnet_side_hole_y_v42 = body_magnet_carrier_y_v42 + panel_t / 2;

door_magnet_carrier_y_v42 = door_inner_y_v42 - panel_t;
magnet_working_gap_v42 = door_magnet_carrier_y_v42
    - body_magnet_face_y_v42;                   // 0.7

// 第29版J形把手板材化参数。
handle_blade_x0_v42 = 3;
handle_z0_v42 = 20;
handle_h_v42 = 155;
handle_clear_depth_v42 = 10;
handle_outer_depth_v42 = 13;
handle_return_w_v42 = 13;
handle_inner_tab_global_z_v42 = [30, 70, 110, 150];
handle_outer_tab_global_z_v42 = [30, 70, 110, 150];
handle_door_lock_global_z_v42 = [55, 140];
handle_return_lock_global_z_v42 = [95, 130];

function handle_local_z_v42(global_z) = global_z - handle_z0_v42;

module v42_slot_rect(center_x, center_z, size_x, size_z) {
    translate([center_x - size_x / 2, center_z - size_z / 2])
        square([size_x, size_z], center = false);
}

module magnet_window_2d_v42() {
    v42_slot_rect(
        magnet_center_v42[0],
        magnet_center_v42[1],
        magnet_window_v42[0],
        magnet_window_v42[1]
    );
}

module magnet_plate_bolt_holes_2d_v42() {
    for (z = magnet_plate_bolt_z_v42)
        translate([magnet_plate_bolt_x_v42, z])
            circle_2d(tnut_screw_d);
}

// 本体磁铁载板从左边缘接受两颗横向M2.5螺丝。
module body_magnet_side_tnut_cut_2d_v42(axis_z) {
    center_x = magnet_plate_x0_v42 + 7;

    translate([
        center_x - tnut_nut_thickness / 2,
        axis_z - tnut_nut_af / 2
    ]) square([tnut_nut_thickness, tnut_nut_af], center = false);

    translate([
        magnet_plate_x0_v42 - 0.01,
        axis_z - tnut_screw_d / 2
    ]) square([
        center_x - magnet_plate_x0_v42 + 0.01,
        tnut_screw_d
    ], center = false);
}

module body_magnet_carrier_2d_v42() {
    difference() {
        translate([magnet_plate_x0_v42, magnet_plate_z0_v42])
            square([magnet_plate_w_v42, magnet_plate_h_v42]);
        magnet_window_2d_v42();
        magnet_plate_bolt_holes_2d_v42();
        for (z = body_magnet_side_lock_z_v42)
            body_magnet_side_tnut_cut_2d_v42(z);
    }
}

module body_magnet_backplate_2d_v42() {
    difference() {
        translate([magnet_plate_x0_v42, magnet_plate_z0_v42])
            square([magnet_plate_w_v42, magnet_plate_h_v42]);
        magnet_plate_bolt_holes_2d_v42();
    }
}

module door_magnet_carrier_2d_v42() {
    difference() {
        translate([magnet_plate_x0_v42, magnet_plate_z0_v42])
            square([magnet_plate_w_v42, magnet_plate_h_v42]);
        magnet_window_2d_v42();
        magnet_plate_bolt_holes_2d_v42();
    }
}

module handle_blade_inner_tnut_cut_2d_v42(global_z) {
    local_z = handle_local_z_v42(global_z);
    center_d = 7;

    translate([
        center_d - tnut_nut_thickness / 2,
        local_z - tnut_nut_af / 2
    ]) square([tnut_nut_thickness, tnut_nut_af]);

    translate([-0.01, local_z - tnut_screw_d / 2])
        square([center_d + 0.01, tnut_screw_d]);
}

module handle_blade_outer_tnut_cut_2d_v42(global_z) {
    local_z = handle_local_z_v42(global_z);
    center_d = handle_clear_depth_v42 - 7;

    translate([
        center_d - tnut_nut_thickness / 2,
        local_z - tnut_nut_af / 2
    ]) square([tnut_nut_thickness, tnut_nut_af]);

    translate([center_d, local_z - tnut_screw_d / 2])
        square([
            handle_clear_depth_v42 - center_d + 0.01,
            tnut_screw_d
        ]);
}

// 把手立板：10 mm净深主体，内外两边各保留四个3 mm装配舌。
module handle_blade_2d_v42() {
    difference() {
        union() {
            square([handle_clear_depth_v42, handle_h_v42]);

            for (z = handle_inner_tab_global_z_v42)
                translate([
                    -panel_t - join_overlap,
                    handle_local_z_v42(z)
                ]) square([panel_t + join_overlap, finger_w]);

            for (z = handle_outer_tab_global_z_v42)
                translate([
                    handle_clear_depth_v42,
                    handle_local_z_v42(z)
                ]) square([panel_t + join_overlap, finger_w]);
        }

        for (z = handle_door_lock_global_z_v42)
            handle_blade_inner_tnut_cut_2d_v42(z);
        for (z = handle_return_lock_global_z_v42)
            handle_blade_outer_tnut_cut_2d_v42(z);
    }
}

module handle_return_2d_v42() {
    difference() {
        square([handle_return_w_v42, handle_h_v42]);

        // 立板外侧装配舌从回折板左缘插入。
        for (z = handle_outer_tab_global_z_v42)
            translate([0, handle_local_z_v42(z)])
                square([slot_w, finger_w]);

        for (z = handle_return_lock_global_z_v42)
            translate([
                panel_t / 2,
                handle_local_z_v42(z)
            ]) circle_2d(tnut_screw_d);
    }
}

module door_panel_2d_v42() {
    difference() {
        square([outer_width, inner_height]);

        // 原第29版右侧外装铰链四孔，孔径保持Ø4.5。
        for (z = door_hinge_hole_z_v42)
            translate([door_hinge_hole_x_v42, z])
                circle_2d(hinge_clearance);

        // 把手立板的四个定位舌与两枚M2.5锁紧螺丝。
        for (z = handle_inner_tab_global_z_v42)
            translate([
                handle_blade_x0_v42
                    + (panel_t - slot_w) / 2,
                z
            ]) square([slot_w, finger_w]);

        for (z = handle_door_lock_global_z_v42)
            translate([handle_blade_x0_v42 + panel_t / 2, z])
                circle_2d(tnut_screw_d);

        // 门侧磁铁载板采用两颗贯穿螺丝，门主板本身充当背板。
        magnet_plate_bolt_holes_2d_v42();
    }
}

// 第41版侧板完整保留，仅在左侧板后部增加本体磁铁载板的两孔。
module side_panel_2d(is_right = false, system = default_joint_system) {
    difference() {
        if (active_geometry_revision >= 2)
            union() {
                polygon(points = [
                    [-screen_base, 0],
                    [inner_depth, 0],
                    [inner_depth, inner_height],
                    [0, inner_height],
                    [0, screen_rise]
                ]);
                side_bottom_fingers_2d();
                side_top_fingers_2d();
            }
        else
            polygon(points = [
                [-screen_base, 0],
                [inner_depth, 0],
                [inner_depth, inner_height],
                [0, inner_height],
                [0, screen_rise]
            ]);

        if (active_geometry_revision < 2) {
            legacy_side_bottom_notches_2d();
            legacy_side_top_notches_2d();
        }

        side_front_notches_2d(is_right);
        for (s0 = screen_joint_starts)
            sloped_edge_notch_2d(s0);
        if (!is_right)
            side_shelf_slots_2d();

        if (system == "wood")
            wood_side_holes_2d();
        else if (system == "tnut") {
            for (y = tnut_axis_y) {
                tnut_edge_cut_2d(y, "bottom");
                tnut_edge_cut_2d(y, "top");
            }

            tnut_edge_cut_2d(right_triangle_bottom_tnut_y_v40,
                "bottom");

            for (z = front_side_tnut_z_v41)
                translate([panel_t / 2, z])
                    circle_2d(tnut_screw_d);

            for (s = screen_side_tnut_s_v41)
                translate(recess_global_point(
                    s,
                    screen_carrier_d + panel_t / 2
                )) circle_2d(tnut_screw_d);
        }

        if (!is_right)
            for (z = body_magnet_side_lock_z_v42)
                translate([body_magnet_side_hole_y_v42, z])
                    circle_2d(tnut_screw_d);

        if (!is_right) magnet_wall_slots_2d_v53();
        if (!is_right) handle_head_reliefs_2d_v58();

        if (is_right)
            right_side_hardware_holes_2d();
    }
}

module body_magnet_cassette_3d_v42() {
    color([0.60, 0.63, 0.70])
        xz_panel_3d(body_magnet_carrier_y_v42)
            body_magnet_carrier_2d_v42();
    color([0.48, 0.52, 0.60])
        xz_panel_3d(body_magnet_back_y_v42)
            body_magnet_backplate_2d_v42();

    %color([0.16, 0.18, 0.20, 0.85])
        translate([
            magnet_center_v42[0] - magnet_nominal_v42[0] / 2,
            body_magnet_face_y_v42 - magnet_nominal_v42[1],
            magnet_center_v42[1] - magnet_nominal_v42[2] / 2
        ]) cube(magnet_nominal_v42);
}

module door_magnet_cassette_3d_v42() {
    color([0.63, 0.66, 0.73])
        xz_panel_3d(door_magnet_carrier_y_v42)
            door_magnet_carrier_2d_v42();

    %color([0.16, 0.18, 0.20, 0.85])
        translate([
            magnet_center_v42[0] - magnet_nominal_v42[0] / 2,
            door_magnet_carrier_y_v42,
            magnet_center_v42[1] - magnet_nominal_v42[2] / 2
        ]) cube(magnet_nominal_v42);
}

module door_handle_3d_v42() {
    color([0.48, 0.38, 0.27])
        yz_panel_3d(handle_blade_x0_v42)
            translate([door_outer_y_v42, handle_z0_v42])
                handle_blade_2d_v42();

    color([0.55, 0.43, 0.29])
        xz_panel_3d(door_outer_y_v42 + handle_clear_depth_v42)
            translate([handle_blade_x0_v42, handle_z0_v42])
                handle_return_2d_v42();
}

module rear_door_assembly_3d_v42() {
    color([0.72, 0.48, 0.36, 0.88])
        xz_panel_3d(door_inner_y_v42)
            door_panel_2d_v42();
    door_magnet_cassette_3d_v42();
    door_handle_3d_v42();
}

module full_assembly_v42(system = default_joint_system) {
    enclosure_assembly(system);
    body_magnet_cassette_3d_v42();
    rear_door_assembly_3d_v42();
}

module body_with_magnet_v42(system = default_joint_system) {
    enclosure_assembly(system);
    body_magnet_cassette_3d_v42();
}

module door_flat_layout_v42() {
    color([0.72, 0.48, 0.36])
        linear_extrude(panel_t) door_panel_2d_v42();

    translate([175, 3, 0])
        color([0.48, 0.38, 0.27])
            linear_extrude(panel_t) handle_blade_2d_v42();

    translate([200, 0, 0])
        color([0.55, 0.43, 0.29])
            linear_extrude(panel_t) handle_return_2d_v42();

    translate([225 - magnet_plate_x0_v42, 0, 0])
        color([0.63, 0.66, 0.73])
            linear_extrude(panel_t) door_magnet_carrier_2d_v42();
}

module body_magnet_flat_layout_v42() {
    translate([-magnet_plate_x0_v42, 0, 0])
        color([0.60, 0.63, 0.70])
            linear_extrude(panel_t) body_magnet_carrier_2d_v42();

    translate([25 - magnet_plate_x0_v42, 0, 0])
        color([0.48, 0.52, 0.60])
            linear_extrude(panel_t) body_magnet_backplate_2d_v42();
}

module full_flat_layout_v42(system = default_joint_system) {
    flat_layout(system);
    translate([700, 0, 0]) door_flat_layout_v42();
    translate([950, 0, 0]) body_magnet_flat_layout_v42();
}

module laser_cut_version_v42(
    system = default_joint_system,
    mode = default_preview_mode
) {
    if (mode == "assembly")
        full_assembly_v42(system);
    else if (mode == "body")
        body_with_magnet_v42(system);
    else if (mode == "door_assembly")
        rear_door_assembly_3d_v42();
    else if (mode == "door_layout")
        door_flat_layout_v42();
    else if (mode == "magnet_parts") {
        linear_extrude(panel_t) body_magnet_carrier_2d_v42();
        translate([30, 0, 0])
            linear_extrude(panel_t) body_magnet_backplate_2d_v42();
        translate([60, 0, 0])
            linear_extrude(panel_t) door_magnet_carrier_2d_v42();
    }
    else if (mode == "layout")
        full_flat_layout_v42(system);
    else
        laser_cut_version(system, mode);
}
