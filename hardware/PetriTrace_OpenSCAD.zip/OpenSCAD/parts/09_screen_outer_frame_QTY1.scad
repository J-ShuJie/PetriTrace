joint_system="tnut";geometry_revision=3;panel_t=3;slot_w=2.9;finger_w=10;large_leaf_on_door_v49=true;show_fastener_references=false;show_sensor_references=false;explode_distance=0;power_exit_v60="door";$hinge_variant_v63="main";show_rpi_reference_v62=false;show_hinge_reference_v60=false;
include <../lib/laser_cut_v63_hinge_screen_common.scad>
screen_outer_frame_2d();
