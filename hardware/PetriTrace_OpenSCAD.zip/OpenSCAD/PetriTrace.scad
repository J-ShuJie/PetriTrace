// v63 source model. Keep the adjacent lib directory. Units: mm.
joint_system="tnut";
geometry_revision=3;
panel_t=3;
slot_w=2.9;
finger_w=10;
large_leaf_on_door_v49=true;
explode_distance=0;
show_fastener_references=false;
show_sensor_references=false;
show_hinge_reference_v60=false; // old schematic hinge shape is not an as-measured solid
show_rpi_reference_v62=false;
power_exit_v60="door";
$hinge_variant_v63="main";
preview_mode="assembly"; // assembly / assembly_with_spares / spare_pair / right_side / door_power / screen_layers
include <lib/laser_cut_v63_hinge_screen_common.scad>
laser_cut_version_v63(preview_mode);
